#!/bin/bash
set -euo pipefail

REPO_URL="${1:-https://github.com/smh0101-dev/project-destiny-display.git}"
VERSION="${2:-v0.6.4}"
TITLE="${3:-ADC1 and duty arcs around speedometer}"

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

if ! command -v git >/dev/null 2>&1; then
  echo "git is required. Install Xcode Command Line Tools first:"
  echo "xcode-select --install"
  exit 1
fi

if [ ! -d .git ]; then
  git init -b main 2>/dev/null || {
    git init
    git branch -M main
  }
fi

if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "$REPO_URL"
else
  git remote add origin "$REPO_URL"
fi

if ! git config user.name >/dev/null; then
  echo "Set your git name first, for example:"
  echo "git config --global user.name \"Spencer Hoff\""
  exit 1
fi

if ! git config user.email >/dev/null; then
  echo "Set your git email first, for example:"
  echo "git config --global user.email \"you@example.com\""
  exit 1
fi

git add .

if git diff --cached --quiet; then
  echo "No staged source changes to commit."
else
  git commit -m "$VERSION: $TITLE"
fi

if git ls-remote --exit-code --heads origin main >/dev/null 2>&1; then
  git fetch origin main
  if ! git merge-base --is-ancestor origin/main HEAD >/dev/null 2>&1; then
    git merge origin/main --allow-unrelated-histories -X ours \
      -m "Merge GitHub initial repository state"
  fi
fi

if ! git rev-parse "$VERSION" >/dev/null 2>&1; then
  git tag -a "$VERSION" -m "$VERSION: $TITLE"
fi

git push -u origin main
git push origin "$VERSION"

echo
echo "GitHub bootstrap complete."
echo "Repo: $REPO_URL"
echo "Tag:  $VERSION"
