#!/bin/bash
set -euo pipefail

VERSION="${1:-}"
TITLE="${2:-}"
REPO="smh0101-dev/project-destiny-display"

if [ -z "$VERSION" ] || [ -z "$TITLE" ]; then
  echo "Usage:"
  echo "  scripts/release-version-macos.command v0.6.5 \"Short release title\""
  exit 1
fi

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PROJECT_NAME="$(basename "$PROJECT_DIR")"
PARENT_DIR="$(dirname "$PROJECT_DIR")"
ZIP_PATH="$PARENT_DIR/RS5-BLE-Telemetry-$VERSION.zip"

cd "$PROJECT_DIR"

if [ ! -d .git ]; then
  echo "This folder is not a git repo yet. Run scripts/bootstrap-github-macos.command first."
  exit 1
fi

git add .
if ! git diff --cached --quiet; then
  git commit -m "$VERSION: $TITLE"
else
  echo "No source changes to commit."
fi

if ! git rev-parse "$VERSION" >/dev/null 2>&1; then
  git tag -a "$VERSION" -m "$VERSION: $TITLE"
else
  echo "Tag $VERSION already exists."
fi

git push origin main
git push origin "$VERSION"

cd "$PARENT_DIR"
rm -f "$ZIP_PATH"
zip -r "$ZIP_PATH" "$PROJECT_NAME" \
  -x "$PROJECT_NAME/.git/*" \
  -x "$PROJECT_NAME/.pio/*" \
  -x "$PROJECT_NAME/.DS_Store" \
  -x "$PROJECT_NAME/*.zip"

if command -v gh >/dev/null 2>&1; then
  if gh release view "$VERSION" --repo "$REPO" >/dev/null 2>&1; then
    gh release upload "$VERSION" "$ZIP_PATH" --repo "$REPO" --clobber
  else
    gh release create "$VERSION" "$ZIP_PATH" \
      --repo "$REPO" \
      --title "$VERSION - $TITLE" \
      --notes-file "$PROJECT_DIR/CHANGELOG.md"
  fi
  echo "GitHub Release updated: https://github.com/$REPO/releases/tag/$VERSION"
else
  echo
  echo "Source and tag were pushed."
  echo "Install GitHub CLI to attach the zip automatically:"
  echo "  brew install gh"
  echo "  gh auth login"
  echo
  echo "Zip created here:"
  echo "  $ZIP_PATH"
  echo "Release page:"
  echo "  https://github.com/$REPO/releases/new?tag=$VERSION"
fi
