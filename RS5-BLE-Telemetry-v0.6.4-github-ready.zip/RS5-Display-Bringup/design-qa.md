# RS5 instrument-cluster design QA

**Source visual truth**

- Path: `/workspace/scratch/90aa37bfd294/upload/512f88b1-5b26-4686-92af-017962a3645f.png`
- Source pixels: 1619 × 971, including the concept's rendered hardware bezel.
- Normalized comparison: 800 × 480 at 1× density.

**Rendered implementation**

- Path: `/tmp/rs5-dashboard-page-1.png`
- All-page contact sheet: `/tmp/rs5-dashboard-all-pages.png`
- Side-by-side comparison: `/tmp/rs5-dashboard-comparison.png`
- Implementation pixels and viewport: 800 × 480 at 1× density.
- Renderer: the project's actual vendored LVGL 8 library, fonts, configuration,
  and `src/dashboard.cpp`, using a headless RGB565 display driver.
- State: primary BLE link, rear over BLE, front over CAN, live representative
  telemetry, SD ready.

**Full-view comparison evidence**

The implementation preserves the concept's dark cockpit hierarchy: narrow status
header, blue/orange outlined side modules, dominant central speed dial, four
segmented lower gauges, and a three-part trip strip. The source's surrounding
bezel is intentionally excluded because the Waveshare hardware supplies the
physical bezel. The actual display's 5:3 aspect ratio is preserved rather than
distorting the UI to the concept render's wider inner-screen crop.

**Focused-region comparison evidence**

A separate crop was not required: at 800 × 480 all header, center-dial, side-card,
segmented-gauge, and footer text remained readable in the full-resolution
side-by-side comparison.

**Required fidelity surfaces**

- Fonts and typography: Montserrat 16/20/32/48 preserves a condensed technical
  hierarchy without adding another flash-heavy font. No clipping remains.
- Spacing and layout rhythm: 10 px outer margin, one-pixel frames, squared corners,
  and consistent panel gaps match the source's dense instrument layout.
- Colors and tokens: near-black surfaces, electric blue, VESC orange, green
  healthy states, yellow regen, and red warning states match the source semantics.
- Image and asset fidelity: the source contains no app-owned photography or
  illustrations. Its hardware bezel is intentionally supplied by the real unit;
  small decorative icons and texture are omitted to preserve legibility and heap.
- Copy and content: decorative values were replaced with live RS5 telemetry.
  Unsupported motor temperatures, faux CAN status, signal strength, and a fake
  SPORT mode were not introduced.

**Comparison history**

1. Initial render found two P2 issues: the FET temperature caption wrapped into
   live values, and the outer dial accents overlapped the header.
2. Fixed by shortening the label to `FET TEMP`, shortening `BATTERY CURRENT` to
   `PACK CURRENT`, moving and reducing the accent arcs, and changing the live arc
   to blue/orange/red speed thresholds.
3. Post-fix render at `/tmp/rs5-dashboard-page-1.png` shows no clipped values,
   overlapping panels, or actionable P0/P1/P2 mismatch.

**Primary interactions tested**

- REC and RESET callbacks remain registered on the Drive page.
- Tileview retains four horizontally scrollable pages.
- Primary/backup state, controller freshness, fault, recording, and no-data
  variants remain represented by the existing update paths.
- Host regression tests passed for BLE role mapping, session statistics, and
  SD logging.
- Browser console checks are not applicable to native LVGL firmware.

**Follow-up polish**

- P3: optional iconography and subtle background texture could move closer to the
  concept, but would add visual noise and memory cost on the 4.3-inch embedded
  target.

**Final result**

final result: passed
