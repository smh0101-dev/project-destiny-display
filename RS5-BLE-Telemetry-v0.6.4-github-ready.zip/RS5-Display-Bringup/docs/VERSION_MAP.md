# Version Map

This file tracks the firmware line at the feature level. Git tags should match
these version names, and GitHub Releases should use the same tag.

| Version | Purpose | Main changes |
| --- | --- | --- |
| `v0.6.1` | Four-page baseline | Drive, Ride Computer, Performance, Dual Controllers, SD logging, BLE failover |
| `v0.6.2` | Splash screen | Panorama Design Studios boot splash added to the v0.6.x branch |
| `v0.6.3` | Drive UI refinement | Motorsport-style Drive page, top status strip, larger speed dial |
| `v0.6.4` | ADC/duty arc layout | ADC1 blue arc, duty orange arc, removed Page 1 duty/max-FET tiles |

## Release Checklist

1. Update `CHANGELOG.md`.
2. Make sure `README.md` still describes the current UI and behavior.
3. Run `upload-macos.command` locally to build and flash-test the display.
4. Run `scripts/release-version-macos.command vX.Y.Z "Short release title"`.
5. Confirm the GitHub Release exists and the firmware artifacts/build status are attached.

