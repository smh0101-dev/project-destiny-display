# Changelog

## v0.6.4 - ADC1 and duty arcs

- Added decoded ADC1 polling from the active VESC BLE bridge.
- Added a blue ADC1 arc around the central speedometer.
- Moved duty cycle from its lower tile into the orange speedometer-side arc.
- Removed the Page 1 duty tile and max FET tile.
- Reworked the Page 1 lower row to keep only battery and regen meters, avoiding overlap with the speedometer cluster.

## v0.6.3 - Drive UI refinement

- Reworked the Drive page toward the motorsport-style concept.
- Added cut-corner panel framing, compact top status strip, link bars, and a larger central speed dial.
- Stabilized rear/front status labels so they show controller health instead of flickering between transport labels.

## v0.6.2 - Panorama splash

- Added the Panorama Design Studios splash screen before the dashboard loads.
- Preserved the four-page v0.6.x dashboard branch after recovery from the older one-page branch.

## v0.6.1 - Four-page baseline

- Added the four-page dashboard layout: Drive, Ride Computer, Performance, and Dual Controllers.
- Added ride-session statistics and SD-card CSV logging.
- Added BLE failover between rear/primary and front/backup controller BLE bridges.

