# BLE and VESC protocol notes

The display is a BLE central. It finds an advertisement whose name begins with
`VESC BLE UART` or advertises Nordic UART Service, then uses:

- Service: `6E400001-B5A3-F393-E0A9-E50E24DCCA9E`
- RX / display writes: `6E400002-B5A3-F393-E0A9-E50E24DCCA9E`
- TX / display subscribes: `6E400003-B5A3-F393-E0A9-E50E24DCCA9E`

The BLE bridge forwards ordinary VESC packets. A short packet is:

`0x02 | payload length | payload | CRC16 high | CRC16 low | 0x03`

CRC is CRC-16/CCITT, polynomial `0x1021`, initial value zero.

## Aggregate telemetry

Command 51 (`COMM_GET_VALUES_SETUP_SELECTIVE`) uses mask `0x003F59DF`. Its
complete request frame is:

`02 05 33 00 3F 59 DF 85 1D 03`

The response includes FET and motor temperature, aggregate motor and pack
current, duty, speed, input voltage, battery level, Wh used/regenerated, absolute
trip distance, fault, controller ID/count, remaining battery Wh, odometer, and
uptime. Range is remaining battery Wh divided by average trip Wh/mi. BLE
notifications may split a VESC frame, so the receiver buffers and CRC-validates
the complete frame before decoding it.

## Individual controllers

`COMM_PING_CAN` discovers the second controller. For each controller, command 50
(`COMM_GET_VALUES_SELECTIVE`) uses mask `0x0002814D`, selecting local FET
temperature, motor current, input current, duty, voltage, fault, and controller
ID. The request is direct for the controller carrying BLE and wrapped in
`COMM_FORWARD_CAN` for the other controller.

Using command 50 is intentional: currents in setup-values command 51 are totals
summed across fresh CAN status messages and therefore are not valid individual
controller readings. Controller ID 39 maps to rear; any other independently
connected controller maps to front. Requests are serialized so identical reply
command IDs cannot be confused.

Bridge addresses are learned only after reading controller ID. Scan-result
addresses are copied before NimBLE releases its result objects. Rear is preferred;
front becomes eligible after 20 seconds without rear. Losing an active front
backup resets the desired role to rear and starts the same fallback timer, which
prevents an offline backup address from permanently excluding a recovered rear
bridge.

Protocol behavior was derived from upstream VESC firmware (`comm/commands.c`,
`motor/mc_interface.c`, and `datatypes.h`), VESC Tool
(`mobile/RtDataSetup.qml`), and the official VESC BLE bridge.

