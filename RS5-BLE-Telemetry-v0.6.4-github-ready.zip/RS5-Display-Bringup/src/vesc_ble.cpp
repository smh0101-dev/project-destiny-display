#include "vesc_ble.h"

#include <NimBLEDevice.h>
#include <cmath>
#include <cstring>
#include <string>

namespace {

constexpr char kTargetName[] = "VESC BLE UART";
constexpr char kNusService[] = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E";
constexpr char kNusRx[] = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E";
constexpr char kNusTx[] = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E";

constexpr uint8_t kCommGetValuesSetupSelective = 51;
constexpr uint8_t kCommGetValuesSelective = 50;
constexpr uint8_t kCommForwardCan = 34;
constexpr uint8_t kCommGetDecodedAdc = 32;
constexpr uint8_t kCommPingCan = 62;
constexpr uint8_t kRearControllerId = 39;
// VESC Tool's range estimate also needs Wh used, Wh regenerated, absolute
// distance and the firmware's remaining-battery-Wh estimate.
constexpr uint32_t kTelemetryMask = 0x003F59DF;
// Local-only controller fields from COMM_GET_VALUES_SELECTIVE: FET temp,
// motor/input current, duty, voltage, fault and controller ID. Unlike the
// setup-values command, these currents are not summed across CAN.
constexpr uint32_t kControllerMask = 0x0002814D;
constexpr float kMetersToMiles = 0.000621371192f;
constexpr float kMinimumRangeDistanceMiles = 0.1f;
constexpr float kMinimumRangeEnergyWh = 0.5f;
constexpr float kMaximumDisplayedRangeMiles = 999.0f;
constexpr uint32_t kPollIntervalMs = 30;
constexpr uint32_t kRequestTimeoutMs = 3000;
constexpr uint32_t kTelemetryTimeoutMs = 4000;
constexpr uint32_t kScanDurationMs = 5000;
constexpr uint32_t kPrimaryFailoverDelayMs = 20000;
constexpr uint32_t kUnidentifiedConnectionTimeoutMs = 6000;
constexpr uint32_t kFailedAddressCooldownMs = 7000;

enum class PendingRequest : uint8_t {
    None,
    Aggregate,
    PingCan,
    LocalController,
    RemoteController,
    DecodedAdc,
};

enum class ControllerRole : uint8_t {
    Unknown,
    RearPrimary,
    FrontBackup,
};

portMUX_TYPE dataMux = portMUX_INITIALIZER_UNLOCKED;
VescTelemetry telemetry;
volatile BleLinkState linkState = BleLinkState::Starting;

NimBLEAddress selectedBleAddress;
bool selectedBleAddressValid = false;
NimBLEClient *client = nullptr;
NimBLERemoteCharacteristic *rxCharacteristic = nullptr;
volatile bool shouldConnect = false;
volatile bool disconnected = false;
uint32_t lastPollMs = 0;
uint32_t requestStartedMs = 0;
uint32_t lastPingAttemptMs = 0;
volatile PendingRequest pendingRequest = PendingRequest::None;
volatile ControllerRole desiredRole = ControllerRole::RearPrimary;
volatile ControllerRole activeRole = ControllerRole::Unknown;
volatile uint8_t localControllerId = 0xFF;
volatile uint8_t remoteControllerId = 0xFF;
volatile bool remoteControllerFound = false;
volatile bool rejectActiveConnection = false;
uint8_t pollPhase = 0;
uint32_t connectedAtMs = 0;
uint32_t primaryOfflineSinceMs = 0;
bool primaryOfflineTimerActive = false;
NimBLEAddress activeBleAddress;
NimBLEAddress primaryBleAddress;
NimBLEAddress backupBleAddress;
NimBLEAddress cooldownBleAddress;
bool activeBleAddressValid = false;
bool primaryBleAddressValid = false;
bool backupBleAddressValid = false;
bool cooldownBleAddressValid = false;
uint32_t cooldownUntilMs = 0;

uint8_t packetBuffer[512];
size_t packetBufferLength = 0;

struct SetupResponse {
    float fetTemp = 0.0f;
    float motorTemp = 0.0f;
    float motorCurrent = 0.0f;
    float batteryCurrent = 0.0f;
    float duty = 0.0f;
    float speedMph = 0.0f;
    float voltage = 0.0f;
    float batteryLevel = 0.0f;
    float wattHours = 0.0f;
    float wattHoursCharged = 0.0f;
    float distanceAbsMeters = 0.0f;
    float batteryWhRemaining = 0.0f;
    float odometerMeters = 0.0f;
    uint32_t uptimeMs = 0;
    uint8_t fault = 0;
    uint8_t controllerId = 0;
    uint8_t controllerCount = 0;
};

void notePrimaryOffline(uint32_t now)
{
    if (!primaryOfflineTimerActive) {
        primaryOfflineSinceMs = now;
        primaryOfflineTimerActive = true;
    }
}

bool primaryFailoverDue(uint32_t now)
{
    return primaryOfflineTimerActive &&
           now - primaryOfflineSinceMs >= kPrimaryFailoverDelayMs;
}

void recoverAfterDisconnect(ControllerRole disconnectedRole, uint32_t now)
{
    if (disconnectedRole == ControllerRole::FrontBackup) {
        // Always prefer a recovered rear controller after losing the backup.
        // If rear is still unavailable, the normal 20-second timer makes the
        // known front address eligible again.
        desiredRole = ControllerRole::RearPrimary;
        primaryOfflineSinceMs = now;
        primaryOfflineTimerActive = true;
    } else {
        notePrimaryOffline(now);
    }
}

ControllerRole roleForControllerId(uint8_t controllerId)
{
    return controllerId == kRearControllerId
        ? ControllerRole::RearPrimary
        : ControllerRole::FrontBackup;
}

bool addressMatchesDesiredRole(const NimBLEAddress &address, uint32_t now)
{
    const bool cooldownActive = cooldownBleAddressValid && cooldownUntilMs != 0 &&
        static_cast<int32_t>(cooldownUntilMs - now) > 0;
    if (cooldownActive && address == cooldownBleAddress) {
        return false;
    }

    if (desiredRole == ControllerRole::RearPrimary) {
        if (primaryBleAddressValid) {
            return address == primaryBleAddress;
        }
        return !backupBleAddressValid || address != backupBleAddress;
    }

    if (backupBleAddressValid) {
        return address == backupBleAddress;
    }
    return !primaryBleAddressValid || address != primaryBleAddress;
}

void clearTelemetry()
{
    portENTER_CRITICAL(&dataMux);
    telemetry = VescTelemetry{};
    portEXIT_CRITICAL(&dataMux);
}

uint16_t crc16(const uint8_t *data, size_t length)
{
    uint16_t crc = 0;
    for (size_t i = 0; i < length; ++i) {
        crc ^= static_cast<uint16_t>(data[i]) << 8;
        for (uint8_t bit = 0; bit < 8; ++bit) {
            crc = (crc & 0x8000U) ? static_cast<uint16_t>((crc << 1) ^ 0x1021U)
                                  : static_cast<uint16_t>(crc << 1);
        }
    }
    return crc;
}

uint16_t readU16(const uint8_t *data, size_t &index)
{
    const uint16_t value = (static_cast<uint16_t>(data[index]) << 8) | data[index + 1];
    index += 2;
    return value;
}

int16_t readI16(const uint8_t *data, size_t &index)
{
    return static_cast<int16_t>(readU16(data, index));
}

uint32_t readU32(const uint8_t *data, size_t &index)
{
    const uint32_t value = (static_cast<uint32_t>(data[index]) << 24) |
                           (static_cast<uint32_t>(data[index + 1]) << 16) |
                           (static_cast<uint32_t>(data[index + 2]) << 8) |
                           static_cast<uint32_t>(data[index + 3]);
    index += 4;
    return value;
}

int32_t readI32(const uint8_t *data, size_t &index)
{
    return static_cast<int32_t>(readU32(data, index));
}

bool decodeSetupPayload(const uint8_t *payload, size_t length, SetupResponse &values)
{
    if (length < 54 || payload[0] != kCommGetValuesSetupSelective) {
        return false;
    }

    size_t index = 1;
    const uint32_t mask = readU32(payload, index);
    if (mask != kTelemetryMask) {
        return false;
    }

    values.fetTemp = readI16(payload, index) / 10.0f;
    values.motorTemp = readI16(payload, index) / 10.0f;
    values.motorCurrent = readI32(payload, index) / 100.0f;
    values.batteryCurrent = readI32(payload, index) / 100.0f;
    values.duty = readI16(payload, index) / 10.0f;
    values.speedMph = (readI32(payload, index) / 1000.0f) * 2.23693629f;
    values.voltage = readI16(payload, index) / 10.0f;
    values.batteryLevel = readI16(payload, index) / 10.0f;
    values.wattHours = readI32(payload, index) / 10000.0f;
    values.wattHoursCharged = readI32(payload, index) / 10000.0f;
    values.distanceAbsMeters = readI32(payload, index) / 1000.0f;
    values.fault = payload[index++];
    values.controllerId = payload[index++];
    values.controllerCount = payload[index++];
    values.batteryWhRemaining = readI32(payload, index) / 1000.0f;
    values.odometerMeters = static_cast<float>(readU32(payload, index));
    values.uptimeMs = readU32(payload, index);
    return true;
}

void parseTelemetryPayload(const uint8_t *payload, size_t length)
{
    SetupResponse values;
    if (!decodeSetupPayload(payload, length, values)) {
        return;
    }

    portENTER_CRITICAL(&dataMux);
    VescTelemetry next = telemetry;
    portEXIT_CRITICAL(&dataMux);

    next.fetTemp = values.fetTemp;
    next.motorTemp = values.motorTemp;
    next.motorCurrent = values.motorCurrent;
    next.batteryCurrent = values.batteryCurrent;
    next.duty = values.duty;
    next.speedMph = values.speedMph;
    next.voltage = values.voltage;
    next.batteryLevel = values.batteryLevel;
    next.wattHours = values.wattHours;
    next.wattHoursCharged = values.wattHoursCharged;
    next.distanceAbsMeters = values.distanceAbsMeters;
    next.fault = values.fault;
    next.controllerId = values.controllerId;
    next.controllerCount = values.controllerCount;
    next.batteryWhRemaining = values.batteryWhRemaining;
    next.odometerMeters = values.odometerMeters;
    next.controllerUptimeMs = values.uptimeMs;
    next.activeControllerIsFront = roleForControllerId(values.controllerId) ==
        ControllerRole::FrontBackup;

    // Match VESC Tool: remaining battery Wh divided by trip-average Wh/mi.
    const float tripWh = next.wattHours - next.wattHoursCharged;
    const float tripMiles = next.distanceAbsMeters * kMetersToMiles;
    const float whPerMile = tripMiles > 0.0f ? tripWh / tripMiles : 0.0f;
    next.estimatedRangeMiles = whPerMile > 0.0f
        ? next.batteryWhRemaining / whPerMile
        : 0.0f;
    next.estimatedRangeValid =
        tripMiles >= kMinimumRangeDistanceMiles &&
        tripWh >= kMinimumRangeEnergyWh &&
        next.batteryWhRemaining >= 0.0f &&
        std::isfinite(next.estimatedRangeMiles) &&
        next.estimatedRangeMiles >= 0.0f &&
        next.estimatedRangeMiles < kMaximumDisplayedRangeMiles;
    next.receivedAtMs = millis();
    next.valid = true;

    const ControllerRole reportedRole = roleForControllerId(values.controllerId);
    const bool newlyIdentified = activeRole != reportedRole ||
        (reportedRole == ControllerRole::RearPrimary &&
         (!primaryBleAddressValid || primaryBleAddress != activeBleAddress)) ||
        (reportedRole == ControllerRole::FrontBackup &&
         (!backupBleAddressValid || backupBleAddress != activeBleAddress));
    localControllerId = next.controllerId;
    activeRole = reportedRole;

    if (reportedRole == ControllerRole::RearPrimary) {
        primaryBleAddress = activeBleAddress;
        primaryBleAddressValid = activeBleAddressValid;
        primaryOfflineTimerActive = false;
        desiredRole = ControllerRole::RearPrimary;
        if (newlyIdentified) {
            Serial.printf("Rear/primary VESC identified: ID %u at %s\n",
                          next.controllerId, activeBleAddress.toString().c_str());
        }
    } else {
        backupBleAddress = activeBleAddress;
        backupBleAddressValid = activeBleAddressValid;
        if (newlyIdentified) {
            Serial.printf("Front/backup VESC identified: ID %u at %s\n",
                          next.controllerId, activeBleAddress.toString().c_str());
        }
        if (desiredRole != ControllerRole::FrontBackup) {
            rejectActiveConnection = true;
            linkState = BleLinkState::WaitingForPrimary;
            if (pendingRequest == PendingRequest::Aggregate) {
                pendingRequest = PendingRequest::None;
            }
            return;
        }
    }

    portENTER_CRITICAL(&dataMux);
    telemetry = next;
    portEXIT_CRITICAL(&dataMux);
    linkState = reportedRole == ControllerRole::RearPrimary
        ? BleLinkState::Connected
        : BleLinkState::ConnectedBackup;
    if (pendingRequest == PendingRequest::Aggregate) {
        pendingRequest = PendingRequest::None;
    }
}

void parseControllerPayload(const uint8_t *payload, size_t length)
{
    if (length < 21 || payload[0] != kCommGetValuesSelective) {
        return;
    }

    size_t index = 1;
    if (readU32(payload, index) != kControllerMask) {
        return;
    }
    ControllerTelemetry controller;
    controller.fetTemp = readI16(payload, index) / 10.0f;
    controller.motorCurrent = readI32(payload, index) / 100.0f;
    controller.batteryCurrent = readI32(payload, index) / 100.0f;
    controller.duty = readI16(payload, index) / 10.0f;
    controller.voltage = readI16(payload, index) / 10.0f;
    controller.fault = payload[index++];
    controller.controllerId = payload[index++];
    if (std::fabs(controller.motorCurrent) < 1.5f) {
        controller.motorCurrent = 0.0f;
    }
    if (std::fabs(controller.batteryCurrent) < 1.5f) {
        controller.batteryCurrent = 0.0f;
    }
    controller.receivedAtMs = millis();
    controller.motorCurrentValid = true;
    controller.valid = true;

    ControllerRole currentRole = ControllerRole::Unknown;
    if (pendingRequest == PendingRequest::LocalController) {
        currentRole = activeRole;
        controller.localBleLink = true;
    } else if (pendingRequest == PendingRequest::RemoteController && remoteControllerFound) {
        currentRole = roleForControllerId(remoteControllerId);
        controller.localBleLink = false;
    }

    portENTER_CRITICAL(&dataMux);
    if (currentRole == ControllerRole::RearPrimary) {
        telemetry.rearMotorCurrent = controller.motorCurrent;
        telemetry.rearMotorCurrentValid = true;
        telemetry.rearController = controller;
    } else if (currentRole == ControllerRole::FrontBackup) {
        telemetry.frontMotorCurrent = controller.motorCurrent;
        telemetry.frontMotorCurrentValid = true;
        telemetry.frontController = controller;
    }
    portEXIT_CRITICAL(&dataMux);

    if (pendingRequest == PendingRequest::LocalController ||
        pendingRequest == PendingRequest::RemoteController) {
        pendingRequest = PendingRequest::None;
    }
}

void parsePingCanPayload(const uint8_t *payload, size_t length)
{
    if (length < 1 || payload[0] != kCommPingCan) {
        return;
    }

    uint8_t selectedId = 0xFF;
    for (size_t i = 1; i < length; ++i) {
        const uint8_t candidateId = payload[i];
        if (candidateId == localControllerId) {
            continue;
        }
        if (activeRole == ControllerRole::FrontBackup && candidateId == kRearControllerId) {
            selectedId = candidateId;
            break;
        }
        if (activeRole == ControllerRole::RearPrimary && candidateId != kRearControllerId) {
            selectedId = candidateId;
            break;
        }
        if (selectedId == 0xFF) {
            selectedId = candidateId;
        }
    }

    if (selectedId != 0xFF) {
        remoteControllerId = selectedId;
        remoteControllerFound = true;
        Serial.printf("Remote VESC discovered on CAN ID %u\n", remoteControllerId);
    } else {
        remoteControllerId = 0xFF;
        remoteControllerFound = false;
        Serial.println("No second VESC responded to CAN ping");
    }
    if (pendingRequest == PendingRequest::PingCan) {
        pendingRequest = PendingRequest::None;
    }
    lastPingAttemptMs = millis();
}

void parseDecodedAdcPayload(const uint8_t *payload, size_t length)
{
    if (length < 9 || payload[0] != kCommGetDecodedAdc) {
        return;
    }

    size_t index = 1;
    const float adc1 = readI32(payload, index) / 1000000.0f;
    const float adc1Voltage = readI32(payload, index) / 1000000.0f;

    portENTER_CRITICAL(&dataMux);
    telemetry.adc1 = adc1;
    telemetry.adc1Voltage = adc1Voltage;
    telemetry.adc1Valid = std::isfinite(adc1) && adc1 >= -0.25f && adc1 <= 1.25f;
    portEXIT_CRITICAL(&dataMux);

    if (pendingRequest == PendingRequest::DecodedAdc) {
        pendingRequest = PendingRequest::None;
    }
}

void consumePacketBuffer()
{
    while (packetBufferLength > 0) {
        size_t start = 0;
        while (start < packetBufferLength && packetBuffer[start] != 2 && packetBuffer[start] != 3) {
            ++start;
        }
        if (start > 0) {
            std::memmove(packetBuffer, packetBuffer + start, packetBufferLength - start);
            packetBufferLength -= start;
        }
        if (packetBufferLength < 5) {
            return;
        }

        const bool shortFrame = packetBuffer[0] == 2;
        const size_t headerLength = shortFrame ? 2 : 3;
        const size_t payloadLength = shortFrame
            ? packetBuffer[1]
            : (static_cast<size_t>(packetBuffer[1]) << 8) | packetBuffer[2];
        const size_t frameLength = headerLength + payloadLength + 3;

        if (frameLength > sizeof(packetBuffer)) {
            std::memmove(packetBuffer, packetBuffer + 1, packetBufferLength - 1);
            --packetBufferLength;
            continue;
        }
        if (packetBufferLength < frameLength) {
            return;
        }

        const size_t payloadIndex = headerLength;
        const size_t crcIndex = payloadIndex + payloadLength;
        const uint16_t expectedCrc = (static_cast<uint16_t>(packetBuffer[crcIndex]) << 8) |
                                     packetBuffer[crcIndex + 1];
        const bool valid = packetBuffer[frameLength - 1] == 3 &&
                           crc16(packetBuffer + payloadIndex, payloadLength) == expectedCrc;
        if (valid) {
            const uint8_t *payload = packetBuffer + payloadIndex;
            if (payloadLength > 0) {
                switch (payload[0]) {
                    case kCommGetValuesSetupSelective:
                        parseTelemetryPayload(payload, payloadLength);
                        break;
                    case kCommGetValuesSelective:
                        parseControllerPayload(payload, payloadLength);
                        break;
                    case kCommPingCan:
                        parsePingCanPayload(payload, payloadLength);
                        break;
                    case kCommGetDecodedAdc:
                        parseDecodedAdcPayload(payload, payloadLength);
                        break;
                    default:
                        break;
                }
            }
        }

        std::memmove(packetBuffer, packetBuffer + frameLength, packetBufferLength - frameLength);
        packetBufferLength -= frameLength;
    }
}

void notificationCallback(NimBLERemoteCharacteristic *, uint8_t *data, size_t length, bool)
{
    if (length > sizeof(packetBuffer) - packetBufferLength) {
        packetBufferLength = 0;
    }
    if (length <= sizeof(packetBuffer)) {
        std::memcpy(packetBuffer + packetBufferLength, data, length);
        packetBufferLength += length;
        consumePacketBuffer();
    }
}

class ClientCallbacks final : public NimBLEClientCallbacks {
    void onConnect(NimBLEClient *) override
    {
        disconnected = false;
    }

    void onDisconnect(NimBLEClient *, int reason) override
    {
        Serial.printf("BLE disconnected (reason %d)\n", reason);
        const ControllerRole disconnectedRole = activeRole;
        if (disconnectedRole == ControllerRole::FrontBackup) {
            Serial.println("Front backup lost; retrying rear/primary first");
        }
        recoverAfterDisconnect(disconnectedRole, millis());
        disconnected = true;
        rxCharacteristic = nullptr;
        activeRole = ControllerRole::Unknown;
        localControllerId = 0xFF;
        remoteControllerId = 0xFF;
        remoteControllerFound = false;
        pendingRequest = PendingRequest::None;
        clearTelemetry();
        linkState = desiredRole == ControllerRole::FrontBackup
            ? BleLinkState::Scanning
            : BleLinkState::WaitingForPrimary;
    }
};

class ScanCallbacks final : public NimBLEScanCallbacks {
    void onResult(const NimBLEAdvertisedDevice *device) override
    {
        bool nameMatches = false;
        if (device->haveName()) {
            const std::string name = device->getName();
            nameMatches = name.rfind(kTargetName, 0) == 0;
        }
        const bool serviceMatches = device->isAdvertisingService(NimBLEUUID(kNusService));
        if (!nameMatches && !serviceMatches) {
            return;
        }

        const NimBLEAddress address = device->getAddress();
        if (!addressMatchesDesiredRole(address, millis())) {
            return;
        }

        Serial.printf("Selected VESC BLE bridge: %s\n", device->toString().c_str());
        // Copy the address (including its public/random address type). Scan-result
        // objects belong to NimBLE and may be released when a retry clears the
        // result list, so never carry their pointers into the main loop.
        selectedBleAddress = address;
        selectedBleAddressValid = true;
        shouldConnect = true;
        NimBLEDevice::getScan()->stop();
    }

    void onScanEnd(const NimBLEScanResults &, int) override
    {
        if (!shouldConnect && linkState != BleLinkState::Connected &&
            linkState != BleLinkState::ConnectedBackup) {
            linkState = desiredRole == ControllerRole::RearPrimary
                ? BleLinkState::WaitingForPrimary
                : BleLinkState::Scanning;
        }
    }
};

ClientCallbacks clientCallbacks;
ScanCallbacks scanCallbacks;

void startScan()
{
    if (NimBLEDevice::getScan()->isScanning()) {
        return;
    }
    selectedBleAddressValid = false;
    linkState = desiredRole == ControllerRole::RearPrimary
        ? BleLinkState::WaitingForPrimary
        : BleLinkState::Scanning;
    NimBLEDevice::getScan()->start(kScanDurationMs, false, true);
}

bool connectToVesc()
{
    if (!selectedBleAddressValid) {
        return false;
    }

    activeBleAddress = selectedBleAddress;
    activeBleAddressValid = true;
    selectedBleAddressValid = false;
    activeRole = ControllerRole::Unknown;
    localControllerId = 0xFF;
    clearTelemetry();
    linkState = BleLinkState::Connecting;
    client = NimBLEDevice::getDisconnectedClient();
    if (client == nullptr) {
        client = NimBLEDevice::createClient();
        if (client == nullptr) {
            return false;
        }
        client->setClientCallbacks(&clientCallbacks, false);
        client->setConnectionParams(12, 24, 0, 200);
        client->setConnectTimeout(5000);
    }

    if (!client->connect(activeBleAddress)) {
        Serial.printf("BLE connection failed for %s\n", activeBleAddress.toString().c_str());
        cooldownBleAddress = activeBleAddress;
        cooldownBleAddressValid = true;
        cooldownUntilMs = millis() + kFailedAddressCooldownMs;
        if (desiredRole == ControllerRole::RearPrimary) {
            notePrimaryOffline(millis());
        }
        return false;
    }

    NimBLERemoteService *service = client->getService(kNusService);
    if (service == nullptr) {
        Serial.println("Nordic UART service not found");
        client->disconnect();
        return false;
    }

    rxCharacteristic = service->getCharacteristic(kNusRx);
    NimBLERemoteCharacteristic *txCharacteristic = service->getCharacteristic(kNusTx);
    if (rxCharacteristic == nullptr || txCharacteristic == nullptr ||
        !rxCharacteristic->canWrite() || !txCharacteristic->canNotify()) {
        Serial.println("Nordic UART characteristics unavailable");
        client->disconnect();
        return false;
    }
    if (!txCharacteristic->subscribe(true, notificationCallback)) {
        Serial.println("BLE notification subscription failed");
        client->disconnect();
        return false;
    }

    packetBufferLength = 0;
    lastPollMs = 0;
    requestStartedMs = 0;
    lastPingAttemptMs = 0;
    pendingRequest = PendingRequest::None;
    remoteControllerId = 0xFF;
    remoteControllerFound = false;
    rejectActiveConnection = false;
    pollPhase = 0;
    connectedAtMs = millis();
    linkState = BleLinkState::Identifying;
    Serial.printf("Connected to VESC BLE bridge %s\n", client->getPeerAddress().toString().c_str());
    return true;
}

bool sendPayload(const uint8_t *payload, size_t payloadLength, PendingRequest request)
{
    if (rxCharacteristic == nullptr || client == nullptr || !client->isConnected()) {
        return false;
    }
    if (payloadLength > 255) {
        return false;
    }

    uint8_t frame[32];
    if (payloadLength + 5 > sizeof(frame)) {
        return false;
    }
    frame[0] = 2;
    frame[1] = static_cast<uint8_t>(payloadLength);
    std::memcpy(frame + 2, payload, payloadLength);
    const uint16_t crc = crc16(payload, payloadLength);
    frame[2 + payloadLength] = static_cast<uint8_t>(crc >> 8);
    frame[3 + payloadLength] = static_cast<uint8_t>(crc);
    frame[4 + payloadLength] = 3;

    pendingRequest = request;
    requestStartedMs = millis();
    if (!rxCharacteristic->writeValue(frame, payloadLength + 5, false)) {
        pendingRequest = PendingRequest::None;
        return false;
    }
    return true;
}

void requestAggregateTelemetry()
{
    const uint8_t payload[] = {
        kCommGetValuesSetupSelective,
        static_cast<uint8_t>(kTelemetryMask >> 24),
        static_cast<uint8_t>(kTelemetryMask >> 16),
        static_cast<uint8_t>(kTelemetryMask >> 8),
        static_cast<uint8_t>(kTelemetryMask),
    };
    sendPayload(payload, sizeof(payload), PendingRequest::Aggregate);
}

void requestCanDiscovery()
{
    const uint8_t payload[] = {kCommPingCan};
    sendPayload(payload, sizeof(payload), PendingRequest::PingCan);
}

void requestLocalControllerTelemetry()
{
    const uint8_t payload[] = {
        kCommGetValuesSelective,
        static_cast<uint8_t>(kControllerMask >> 24),
        static_cast<uint8_t>(kControllerMask >> 16),
        static_cast<uint8_t>(kControllerMask >> 8),
        static_cast<uint8_t>(kControllerMask),
    };
    sendPayload(payload, sizeof(payload), PendingRequest::LocalController);
}

void requestRemoteControllerTelemetry()
{
    if (!remoteControllerFound) {
        return;
    }
    const uint8_t payload[] = {
        kCommForwardCan,
        remoteControllerId,
        kCommGetValuesSelective,
        static_cast<uint8_t>(kControllerMask >> 24),
        static_cast<uint8_t>(kControllerMask >> 16),
        static_cast<uint8_t>(kControllerMask >> 8),
        static_cast<uint8_t>(kControllerMask),
    };
    sendPayload(payload, sizeof(payload), PendingRequest::RemoteController);
}

void requestDecodedAdc()
{
    const uint8_t payload[] = {kCommGetDecodedAdc};
    sendPayload(payload, sizeof(payload), PendingRequest::DecodedAdc);
}

}  // namespace

void vescBleBegin()
{
    NimBLEDevice::init("RS5 Display");
    NimBLEDevice::setPower(3);
    NimBLEScan *scan = NimBLEDevice::getScan();
    scan->setScanCallbacks(&scanCallbacks, false);
    scan->setInterval(100);
    scan->setWindow(80);
    scan->setActiveScan(true);
    desiredRole = ControllerRole::RearPrimary;
    notePrimaryOffline(millis());
    startScan();
}

void vescBleLoop()
{
    const uint32_t now = millis();

    if (desiredRole == ControllerRole::RearPrimary && primaryFailoverDue(now)) {
        desiredRole = ControllerRole::FrontBackup;
        Serial.println("Primary offline for 20 seconds; enabling front BLE backup");
        if (client != nullptr && client->isConnected() &&
            activeRole != ControllerRole::FrontBackup) {
            client->disconnect();
            return;
        }
    }

    if (rejectActiveConnection) {
        rejectActiveConnection = false;
        if (client != nullptr && client->isConnected()) {
            Serial.println("Front BLE identified; continuing search for rear/primary");
            client->disconnect();
            return;
        }
    }

    if (disconnected) {
        disconnected = false;
        startScan();
    }
    if (shouldConnect) {
        shouldConnect = false;
        if (!connectToVesc()) {
            startScan();
        } else {
            // connectToVesc() is synchronous and updates connectedAtMs. The
            // `now` captured at the top of this loop is therefore older than
            // connectedAtMs; using it for the timeout check below would wrap
            // the unsigned subtraction and disconnect immediately. Start the
            // telemetry/identification phase on the next loop with fresh time.
            return;
        }
    }
    if (client == nullptr || !client->isConnected()) {
        if (!NimBLEDevice::getScan()->isScanning()) {
            startScan();
        }
        return;
    }

    if (pendingRequest != PendingRequest::None && now - requestStartedMs > kRequestTimeoutMs) {
        Serial.println("VESC request timed out");
        pendingRequest = PendingRequest::None;
    }

    const VescTelemetry current = vescBleSnapshot();
    if (activeRole == ControllerRole::Unknown && !current.valid &&
        now - connectedAtMs >= kUnidentifiedConnectionTimeoutMs) {
        Serial.printf("No controller response through %s; trying the other BLE bridge\n",
                      activeBleAddress.toString().c_str());
        cooldownBleAddress = activeBleAddress;
        cooldownBleAddressValid = true;
        cooldownUntilMs = now + kFailedAddressCooldownMs;
        if (desiredRole == ControllerRole::RearPrimary) {
            notePrimaryOffline(now);
        }
        client->disconnect();
        return;
    }

    if (activeRole == ControllerRole::RearPrimary &&
        (!current.valid || now - current.receivedAtMs > kTelemetryTimeoutMs)) {
        if (!primaryOfflineTimerActive) {
            primaryOfflineSinceMs = current.valid ? current.receivedAtMs : connectedAtMs;
            primaryOfflineTimerActive = true;
        }
        linkState = BleLinkState::WaitingForPrimary;
        if (primaryFailoverDue(now)) {
            desiredRole = ControllerRole::FrontBackup;
            Serial.println("Rear/primary telemetry timed out; switching to front BLE backup");
            client->disconnect();
            return;
        }
    }

    if (pendingRequest == PendingRequest::None && now - lastPollMs >= kPollIntervalMs) {
        lastPollMs = now;
        if (!current.valid) {
            requestAggregateTelemetry();
        } else if (!remoteControllerFound && now - lastPingAttemptMs > 3000) {
            lastPingAttemptMs = now;
            requestCanDiscovery();
        } else {
            switch (pollPhase++ % 4) {
                case 0:
                    requestAggregateTelemetry();
                    break;
                case 1:
                    requestLocalControllerTelemetry();
                    break;
                case 2:
                    if (remoteControllerFound) {
                        requestRemoteControllerTelemetry();
                    } else {
                        requestAggregateTelemetry();
                    }
                    break;
                case 3:
                    requestDecodedAdc();
                    break;
            }
        }
    }

    if (activeRole == ControllerRole::FrontBackup &&
        (!current.valid || now - current.receivedAtMs > kTelemetryTimeoutMs)) {
        linkState = BleLinkState::NoTelemetry;
    }
}

VescTelemetry vescBleSnapshot()
{
    portENTER_CRITICAL(&dataMux);
    const VescTelemetry copy = telemetry;
    portEXIT_CRITICAL(&dataMux);
    return copy;
}

BleLinkState vescBleState()
{
    return linkState;
}

const char *vescBleStateText(BleLinkState state)
{
    switch (state) {
        case BleLinkState::Starting: return "STARTING";
        case BleLinkState::Scanning: return "SCANNING";
        case BleLinkState::Connecting: return "CONNECTING";
        case BleLinkState::Identifying: return "VESC CHECK";
        case BleLinkState::Connected: return "CONNECTED";
        case BleLinkState::WaitingForPrimary: return "PRIMARY WAIT";
        case BleLinkState::ConnectedBackup: return "FRONT BACKUP";
        case BleLinkState::NoTelemetry: return "NO DATA";
    }
    return "UNKNOWN";
}

const char *vescFaultText(uint8_t fault)
{
    static const char *const names[] = {
        "NONE", "OVER VOLT", "UNDER VOLT", "DRV", "OVER CURRENT",
        "FET HOT", "MOTOR HOT", "GATE OVER V", "GATE UNDER V", "MCU UNDER V",
        "WATCHDOG", "ENCODER SPI", "ENC LOW AMP", "ENC HIGH AMP", "FLASH",
        "CS1 OFFSET", "CS2 OFFSET", "CS3 OFFSET", "UNBALANCED", "BRAKE",
        "RESOLVER LOT", "RESOLVER DOS", "RESOLVER LOS", "APP CFG", "MC CFG",
        "NO MAGNET", "MAGNET STRONG", "PHASE FILTER", "ENCODER", "LV OUTPUT",
        "ENCODER SLIP", "OVERSPEED", "UNDERSPEED", "ABS OVERSPEED"
    };
    return fault < (sizeof(names) / sizeof(names[0])) ? names[fault] : "FAULT";
}
