#include "ride_session.h"

#include <cmath>

namespace {

constexpr float kMetersToMiles = 0.000621371192f;
constexpr float kMovingThresholdMph = 1.0f;
constexpr float kAccelerationStartMph = 1.5f;
constexpr float kMaximumReasonableDistanceDeltaMeters = 500.0f;
constexpr float kMaximumReasonableEnergyDeltaWh = 100.0f;

RideStats stats;
uint32_t resetAtMs = 0;
uint32_t lastSampleAtMs = 0;
float lastDistanceMeters = 0.0f;
float lastWattHours = 0.0f;
float lastWattHoursCharged = 0.0f;
float previousSpeedMph = 0.0f;
uint8_t lastControllerId = 0xFF;
bool liveConsumptionValid = false;
bool accelerationArmed = true;
bool accelerationRunning = false;
uint32_t accelerationStartedMs = 0;

void captureBaselines(const VescTelemetry &telemetry)
{
    lastDistanceMeters = telemetry.distanceAbsMeters;
    lastWattHours = telemetry.wattHours;
    lastWattHoursCharged = telemetry.wattHoursCharged;
    lastSampleAtMs = telemetry.receivedAtMs;
    lastControllerId = telemetry.controllerId;
    previousSpeedMph = std::fabs(telemetry.speedMph);
}

void captureAcceleration(float speedMph, uint32_t sampleAtMs)
{
    if (speedMph <= kMovingThresholdMph) {
        accelerationArmed = true;
        accelerationRunning = false;
        previousSpeedMph = speedMph;
        return;
    }

    if (accelerationArmed && speedMph >= kAccelerationStartMph) {
        accelerationArmed = false;
        accelerationRunning = true;
        accelerationStartedMs = sampleAtMs;
    }

    if (!accelerationRunning) {
        previousSpeedMph = speedMph;
        return;
    }

    const float elapsedSeconds = (sampleAtMs - accelerationStartedMs) / 1000.0f;
    auto captureThreshold = [&](float threshold, float &best) {
        if (previousSpeedMph < threshold && speedMph >= threshold &&
            (best <= 0.0f || elapsedSeconds < best)) {
            best = elapsedSeconds;
        }
    };
    captureThreshold(20.0f, stats.zeroTo20Seconds);
    captureThreshold(30.0f, stats.zeroTo30Seconds);
    captureThreshold(40.0f, stats.zeroTo40Seconds);
    if (speedMph >= 40.0f || elapsedSeconds > 30.0f) {
        accelerationRunning = false;
    }
    previousSpeedMph = speedMph;
}

}  // namespace

void rideSessionBegin(uint32_t now)
{
    stats = RideStats{};
    resetAtMs = now;
    lastSampleAtMs = 0;
    lastControllerId = 0xFF;
    liveConsumptionValid = false;
    accelerationArmed = true;
    accelerationRunning = false;
}

void rideSessionReset(const VescTelemetry &telemetry, uint32_t now)
{
    rideSessionBegin(now);
    if (telemetry.valid) {
        stats.initialized = true;
        stats.minimumVoltage = telemetry.voltage;
        captureBaselines(telemetry);
    }
}

void rideSessionUpdate(const VescTelemetry &telemetry, uint32_t now)
{
    if (!telemetry.valid || telemetry.receivedAtMs == 0 ||
        telemetry.receivedAtMs == lastSampleAtMs) {
        if (stats.initialized) {
            stats.elapsedMs = now - resetAtMs;
        }
        return;
    }

    const float speedMph = std::fabs(telemetry.speedMph);
    if (!stats.initialized) {
        stats.initialized = true;
        stats.minimumVoltage = telemetry.voltage;
        resetAtMs = now;
        captureBaselines(telemetry);
        return;
    }

    const uint32_t sampleAtMs = telemetry.receivedAtMs;
    const uint32_t deltaMs = sampleAtMs - lastSampleAtMs;
    stats.elapsedMs = now - resetAtMs;
    if (speedMph > kMovingThresholdMph && deltaMs < 10000) {
        stats.movingMs += deltaMs;
    }

    // A failover can move the requests to the other controller. Suppress the
    // first cumulative-counter delta after that transition so two different
    // controller histories cannot create a fake trip jump.
    if (telemetry.controllerId != lastControllerId) {
        captureBaselines(telemetry);
    } else {
        const float distanceDelta = telemetry.distanceAbsMeters - lastDistanceMeters;
        if (distanceDelta >= 0.0f && distanceDelta <= kMaximumReasonableDistanceDeltaMeters) {
            stats.tripMiles += distanceDelta * kMetersToMiles;
        }

        const float usedDelta = telemetry.wattHours - lastWattHours;
        const float chargedDelta = telemetry.wattHoursCharged - lastWattHoursCharged;
        const float netDelta = usedDelta - chargedDelta;
        if (std::fabs(netDelta) <= kMaximumReasonableEnergyDeltaWh &&
            usedDelta >= -kMaximumReasonableEnergyDeltaWh &&
            chargedDelta >= -kMaximumReasonableEnergyDeltaWh) {
            stats.netWattHours += netDelta;
        }

        lastDistanceMeters = telemetry.distanceAbsMeters;
        lastWattHours = telemetry.wattHours;
        lastWattHoursCharged = telemetry.wattHoursCharged;
        lastSampleAtMs = sampleAtMs;
    }

    const float packPowerKw = telemetry.voltage * telemetry.batteryCurrent / 1000.0f;
    stats.topSpeedMph = fmaxf(stats.topSpeedMph, speedMph);
    stats.peakPowerKw = fmaxf(stats.peakPowerKw, packPowerKw);
    stats.minimumVoltage = fminf(stats.minimumVoltage, telemetry.voltage);
    stats.peakBatteryCurrent = fmaxf(stats.peakBatteryCurrent, telemetry.batteryCurrent);
    stats.peakRegenCurrent = fminf(stats.peakRegenCurrent, telemetry.batteryCurrent);
    stats.maximumFetTemp = fmaxf(stats.maximumFetTemp, telemetry.fetTemp);
    if (telemetry.frontMotorCurrentValid) {
        stats.peakFrontMotorCurrent = fmaxf(
            stats.peakFrontMotorCurrent, std::fabs(telemetry.frontMotorCurrent)
        );
    }
    if (telemetry.rearMotorCurrentValid) {
        stats.peakRearMotorCurrent = fmaxf(
            stats.peakRearMotorCurrent, std::fabs(telemetry.rearMotorCurrent)
        );
    }

    if (stats.tripMiles >= 0.01f) {
        stats.averageWhPerMile = stats.netWattHours / stats.tripMiles;
    }
    if (stats.movingMs > 0) {
        stats.averageSpeedMph = stats.tripMiles / (stats.movingMs / 3600000.0f);
    }
    if (speedMph >= 2.0f) {
        const float instant = packPowerKw * 1000.0f / speedMph;
        stats.liveWhPerMile = liveConsumptionValid
            ? stats.liveWhPerMile * 0.85f + instant * 0.15f
            : instant;
        liveConsumptionValid = true;
    }

    captureAcceleration(speedMph, sampleAtMs);
    lastControllerId = telemetry.controllerId;
}

RideStats rideSessionSnapshot()
{
    return stats;
}

