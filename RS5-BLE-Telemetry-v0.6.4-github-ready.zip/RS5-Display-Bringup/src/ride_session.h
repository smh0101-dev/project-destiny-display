#pragma once

#include <Arduino.h>

#include "vesc_ble.h"

struct RideStats {
    bool initialized = false;
    float tripMiles = 0.0f;
    float netWattHours = 0.0f;
    float averageWhPerMile = 0.0f;
    float liveWhPerMile = 0.0f;
    float averageSpeedMph = 0.0f;
    float topSpeedMph = 0.0f;
    float peakPowerKw = 0.0f;
    float minimumVoltage = 0.0f;
    float peakBatteryCurrent = 0.0f;
    float peakRegenCurrent = 0.0f;
    float peakFrontMotorCurrent = 0.0f;
    float peakRearMotorCurrent = 0.0f;
    float maximumFetTemp = 0.0f;
    float zeroTo20Seconds = 0.0f;
    float zeroTo30Seconds = 0.0f;
    float zeroTo40Seconds = 0.0f;
    uint32_t elapsedMs = 0;
    uint32_t movingMs = 0;
};

void rideSessionBegin(uint32_t now);
void rideSessionReset(const VescTelemetry &telemetry, uint32_t now);
void rideSessionUpdate(const VescTelemetry &telemetry, uint32_t now);
RideStats rideSessionSnapshot();

