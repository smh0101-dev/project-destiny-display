#include "ride_logger.h"

#include <FS.h>
#include <SD.h>
#include <SPI.h>
#include <esp_io_expander.hpp>

#include <cmath>
#include <cstdio>

namespace {

constexpr int kSdCsExpanderPin = 4;
constexpr int kSdMosiPin = 11;
constexpr int kSdClockPin = 12;
constexpr int kSdMisoPin = 13;
constexpr int kSdHardwareCsPin = -1;
constexpr uint32_t kLogIntervalMs = 500;

esp_expander::Base *ioExpander = nullptr;
File logFile;
RideLogState logState = RideLogState::NoCard;
uint32_t lastLogMs = 0;
uint16_t rowsSinceFlush = 0;

bool mountCard()
{
    if (ioExpander == nullptr) {
        logState = RideLogState::Error;
        return false;
    }

    ioExpander->digitalWrite(kSdCsExpanderPin, LOW);
    SPI.setHwCs(false);
    SPI.begin(kSdClockPin, kSdMisoPin, kSdMosiPin, kSdHardwareCsPin);
    if (!SD.begin(kSdHardwareCsPin, SPI, 10000000) || SD.cardType() == CARD_NONE) {
        Serial.println("RS5 logger: no microSD card mounted");
        logState = RideLogState::NoCard;
        return false;
    }
    if (!SD.exists("/RS5") && !SD.mkdir("/RS5")) {
        Serial.println("RS5 logger: could not create /RS5 directory");
        logState = RideLogState::Error;
        return false;
    }
    logState = RideLogState::Ready;
    Serial.printf("RS5 logger: microSD ready (%llu MB)\n", SD.cardSize() / (1024 * 1024));
    return true;
}

bool openNextRideFile()
{
    char path[32];
    for (unsigned rideNumber = 1; rideNumber <= 9999; ++rideNumber) {
        snprintf(path, sizeof(path), "/RS5/ride_%04u.csv", rideNumber);
        if (!SD.exists(path)) {
            logFile = SD.open(path, FILE_WRITE);
            if (!logFile) {
                logState = RideLogState::Error;
                return false;
            }
            logFile.println(
                "elapsed_s,moving_s,controller_id,backup_link,speed_mph,pack_v,pack_a,"
                "power_kw,battery_pct,range_mi,front_motor_a,rear_motor_a,fet_temp_c,"
                "duty_pct,trip_mi,net_wh,avg_wh_mi,live_wh_mi,front_fet_c,rear_fet_c,"
                "front_fault,rear_fault"
            );
            logFile.flush();
            Serial.printf("RS5 logger: recording %s\n", path);
            return true;
        }
    }
    logState = RideLogState::Error;
    return false;
}

}  // namespace

void rideLoggerBegin(esp_expander::Base *expander)
{
    ioExpander = expander;
    mountCard();
}

bool rideLoggerStart(const VescTelemetry &telemetry, const RideStats &stats)
{
    if (logState == RideLogState::Recording) {
        return true;
    }
    if (logState != RideLogState::Ready && !mountCard()) {
        return false;
    }
    if (!openNextRideFile()) {
        Serial.println("RS5 logger: unable to open a new ride file");
        return false;
    }
    lastLogMs = 0;
    rowsSinceFlush = 0;
    logState = RideLogState::Recording;
    rideLoggerTick(telemetry, stats, millis());
    return true;
}

void rideLoggerStop()
{
    if (logFile) {
        logFile.flush();
        logFile.close();
    }
    if (logState == RideLogState::Recording) {
        logState = RideLogState::Ready;
        Serial.println("RS5 logger: recording stopped");
    }
}

void rideLoggerTick(const VescTelemetry &telemetry, const RideStats &stats, uint32_t now)
{
    if (logState != RideLogState::Recording || !telemetry.valid ||
        now - lastLogMs < kLogIntervalMs) {
        return;
    }
    lastLogMs = now;

    const bool backupLink = telemetry.activeControllerIsFront;
    const float range = telemetry.estimatedRangeValid ? telemetry.estimatedRangeMiles : NAN;
    const float frontCurrent = telemetry.frontMotorCurrentValid ? telemetry.frontMotorCurrent : NAN;
    const float rearCurrent = telemetry.rearMotorCurrentValid ? telemetry.rearMotorCurrent : NAN;
    const float frontFet = telemetry.frontController.valid ? telemetry.frontController.fetTemp : NAN;
    const float rearFet = telemetry.rearController.valid ? telemetry.rearController.fetTemp : NAN;
    const int frontFault = telemetry.frontController.valid ? telemetry.frontController.fault : -1;
    const int rearFault = telemetry.rearController.valid ? telemetry.rearController.fault : -1;

    char row[512];
    const int length = snprintf(
        row, sizeof(row),
        "%.1f,%.1f,%u,%u,%.2f,%.2f,%.2f,%.3f,%.1f,%.2f,%.2f,%.2f,%.1f,"
        "%.1f,%.4f,%.2f,%.2f,%.2f,%.1f,%.1f,%d,%d\n",
        stats.elapsedMs / 1000.0f, stats.movingMs / 1000.0f,
        telemetry.controllerId, backupLink ? 1U : 0U,
        telemetry.speedMph, telemetry.voltage, telemetry.batteryCurrent,
        telemetry.voltage * telemetry.batteryCurrent / 1000.0f,
        telemetry.batteryLevel, range, frontCurrent, rearCurrent, telemetry.fetTemp,
        telemetry.duty, stats.tripMiles, stats.netWattHours, stats.averageWhPerMile,
        stats.liveWhPerMile, frontFet, rearFet, frontFault, rearFault
    );
    if (length <= 0 || static_cast<size_t>(length) >= sizeof(row) || !logFile.print(row)) {
        Serial.println("RS5 logger: write failed");
        rideLoggerStop();
        logState = RideLogState::Error;
        return;
    }
    if (++rowsSinceFlush >= 10) {
        logFile.flush();
        rowsSinceFlush = 0;
    }
}

RideLogState rideLoggerState()
{
    return logState;
}

const char *rideLoggerStateText(RideLogState state)
{
    switch (state) {
        case RideLogState::NoCard: return "NO SD";
        case RideLogState::Ready: return "SD READY";
        case RideLogState::Recording: return "RECORDING";
        case RideLogState::Error: return "SD ERROR";
    }
    return "SD ERROR";
}

