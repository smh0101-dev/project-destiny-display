#pragma once

#include "ride_logger.h"
#include "ride_session.h"
#include "vesc_ble.h"

enum class DashboardAction : uint8_t {
    None,
    ToggleRecording,
    ResetSession,
};

void dashboardBuild();
void dashboardShowSplash();
void dashboardUpdate(const VescTelemetry &telemetry, BleLinkState state,
                     const RideStats &stats, RideLogState logState);
DashboardAction dashboardTakeAction();
