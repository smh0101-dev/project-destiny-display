#pragma once

#include <Arduino.h>

#include "ride_session.h"
#include "vesc_ble.h"

namespace esp_expander {
class Base;
}

enum class RideLogState : uint8_t {
    NoCard,
    Ready,
    Recording,
    Error,
};

void rideLoggerBegin(esp_expander::Base *expander);
bool rideLoggerStart(const VescTelemetry &telemetry, const RideStats &stats);
void rideLoggerStop();
void rideLoggerTick(const VescTelemetry &telemetry, const RideStats &stats, uint32_t now);
RideLogState rideLoggerState();
const char *rideLoggerStateText(RideLogState state);

