#include <Arduino.h>
#include <esp_display_panel.hpp>
#include <esp_err.h>
#include <lvgl.h>

#include "esp_lv_adapter_arduino.h"
#include "dashboard.h"
#include "ride_logger.h"
#include "ride_session.h"
#include "vesc_ble.h"

using namespace esp_panel::board;
using namespace esp_panel::drivers;

void setup()
{
    Serial.begin(115200);
    delay(600);
    Serial.println("RS5 display bring-up starting");

    Board *board = new Board();
    if ((board == nullptr) || !board->init()) {
        Serial.println("ERROR: Board initialization failed");
        while (true) {
            delay(1000);
        }
    }

    constexpr esp_lv_adapter_rotation_t rotation = ESP_LV_ADAPTER_ROTATE_0;
    constexpr esp_lv_adapter_tear_avoid_mode_t tear_mode = ESP_LV_ADAPTER_TEAR_AVOID_MODE_DEFAULT_RGB;

    LCD *lcd = board->getLCD();
    if (lcd == nullptr) {
        Serial.println("ERROR: LCD device unavailable");
        while (true) {
            delay(1000);
        }
    }

    const uint8_t frame_buffer_count = esp_lv_adapter_get_required_frame_buffer_count(tear_mode, rotation);
    auto *lcd_bus = lcd->getBus();
    if (lcd_bus->getBasicAttributes().type == ESP_PANEL_BUS_TYPE_RGB) {
        lcd->configFrameBufferNumber(frame_buffer_count);
        static_cast<BusRGB *>(lcd_bus)->configRGB_BounceBufferSize(lcd->getFrameWidth() * 10);
    }

    if (!board->begin()) {
        Serial.println("ERROR: Board startup failed");
        while (true) {
            delay(1000);
        }
    }

    esp_lv_adapter_config_t adapter_config = ESP_LV_ADAPTER_DEFAULT_CONFIG();
    adapter_config.task_stack_size = 12 * 1024;
    adapter_config.task_priority = 2;
    adapter_config.task_core_id = ARDUINO_RUNNING_CORE;
    ESP_ERROR_CHECK(esp_lv_adapter_init(&adapter_config));

    esp_lv_adapter_display_config_t display_config = ESP_LV_ADAPTER_DISPLAY_RGB_DEFAULT_CONFIG(
        lcd, lcd->getFrameWidth(), lcd->getFrameHeight(), rotation
    );
    display_config.profile.use_psram = true;

    lv_display_t *display = esp_lv_adapter_register_display(&display_config);
    if (display == nullptr) {
        Serial.println("ERROR: LVGL display registration failed");
        while (true) {
            delay(1000);
        }
    }

    if (board->getTouch() != nullptr) {
        esp_lv_adapter_touch_config_t touch_config = ESP_LV_ADAPTER_TOUCH_DEFAULT_CONFIG(display, board->getTouch());
        if (esp_lv_adapter_register_touch(&touch_config) == nullptr) {
            Serial.println("WARNING: Touch registration failed");
        }
    } else {
        Serial.println("WARNING: Touch controller unavailable");
    }

    ESP_ERROR_CHECK(esp_lv_adapter_start());
    ESP_ERROR_CHECK(esp_lv_adapter_lock(-1));
    dashboardShowSplash();
    esp_lv_adapter_unlock();

    delay(1800);

    ESP_ERROR_CHECK(esp_lv_adapter_lock(-1));
    dashboardBuild();
    esp_lv_adapter_unlock();

    rideSessionBegin(millis());
    rideLoggerBegin(board->getIO_Expander() == nullptr
        ? nullptr
        : board->getIO_Expander()->getBase());
    vescBleBegin();
    Serial.println("RS5 four-page telemetry dashboard ready");
}

void loop()
{
    vescBleLoop();

    const VescTelemetry telemetry = vescBleSnapshot();
    rideSessionUpdate(telemetry, millis());

    const DashboardAction action = dashboardTakeAction();
    if (action == DashboardAction::ToggleRecording) {
        if (rideLoggerState() == RideLogState::Recording) {
            rideLoggerStop();
        } else {
            rideLoggerStart(telemetry, rideSessionSnapshot());
        }
    } else if (action == DashboardAction::ResetSession) {
        const bool restartRecording = rideLoggerState() == RideLogState::Recording;
        if (restartRecording) {
            rideLoggerStop();
        }
        rideSessionReset(telemetry, millis());
        if (restartRecording) {
            rideLoggerStart(telemetry, rideSessionSnapshot());
        }
        Serial.println("RS5 ride session reset");
    }
    const RideStats stats = rideSessionSnapshot();
    rideLoggerTick(telemetry, stats, millis());

    static uint32_t lastUiUpdateMs = 0;
    const uint32_t now = millis();
    if (now - lastUiUpdateMs >= 100) {
        lastUiUpdateMs = now;
        if (esp_lv_adapter_lock(25) == ESP_OK) {
            dashboardUpdate(telemetry, vescBleState(), stats, rideLoggerState());
            esp_lv_adapter_unlock();
        }
    }
    delay(5);
}
