#include "dashboard.h"

#include <lvgl.h>

#include <algorithm>
#include <cmath>
#include <cstdio>

LV_IMG_DECLARE(panorama_splash_logo);

namespace {

constexpr uint32_t kBg = 0x03070A;
constexpr uint32_t kPanel = 0x080E13;
constexpr uint32_t kPanelBlue = 0x0B141C;
constexpr uint32_t kTrack = 0x1B2730;
constexpr uint32_t kMuted = 0x8494A1;
constexpr uint32_t kOrange = 0xFF5A1F;
constexpr uint32_t kOrangeDim = 0x6A2A18;
constexpr uint32_t kGreen = 0x59E34A;
constexpr uint32_t kRed = 0xFF3B30;
constexpr uint32_t kYellow = 0xFFD23F;
constexpr uint32_t kWhite = 0xF7F9FB;
constexpr uint32_t kBlue = 0x2997FF;
constexpr uint32_t kBlueDim = 0x164B70;
constexpr int kSegmentCount = 10;
constexpr int kVectorLineCapacity = 220;

volatile DashboardAction pendingAction = DashboardAction::None;

lv_obj_t *speedArc;
lv_obj_t *adcArc;
lv_obj_t *dutyArc;
lv_obj_t *speedValue;
lv_obj_t *adcArcValue;
lv_obj_t *dutyArcValue;
lv_obj_t *linkDot;
lv_obj_t *linkLabel;
lv_obj_t *rearStatusLabel;
lv_obj_t *frontStatusLabel;
lv_obj_t *batteryValue;
lv_obj_t *rangeValue;
lv_obj_t *voltageValue;
lv_obj_t *powerValue;
lv_obj_t *batteryCurrentValue;
lv_obj_t *frontMotorCurrentValue;
lv_obj_t *rearMotorCurrentValue;
lv_obj_t *frontFetTempValue;
lv_obj_t *rearFetTempValue;
lv_obj_t *regenValue;
lv_obj_t *batteryGaugeValue;
lv_obj_t *controllersValue;
lv_obj_t *faultPanel;
lv_obj_t *faultValue;
lv_obj_t *recordButton;
lv_obj_t *recordButtonLabel;
lv_obj_t *recordStateLabel;
lv_obj_t *driveTripValue;
lv_obj_t *driveEfficiencyValue;
lv_obj_t *topBatteryCells[4]{};
lv_obj_t *linkBars[4]{};

lv_obj_t *tripValue;
lv_obj_t *elapsedValue;
lv_obj_t *movingValue;
lv_obj_t *averageSpeedValue;
lv_obj_t *averageConsumptionValue;
lv_obj_t *liveConsumptionValue;
lv_obj_t *energyValue;
lv_obj_t *rideRangeValue;
lv_obj_t *odometerValue;
lv_obj_t *uptimeValue;
lv_obj_t *rideLogStateValue;

lv_obj_t *topSpeedValue;
lv_obj_t *peakPowerValue;
lv_obj_t *performanceAverageSpeedValue;
lv_obj_t *zeroTo20Value;
lv_obj_t *zeroTo30Value;
lv_obj_t *zeroTo40Value;
lv_obj_t *minimumVoltageValue;
lv_obj_t *peakBatteryValue;
lv_obj_t *peakRegenValue;
lv_obj_t *maximumFetValue;
lv_obj_t *peakFrontValue;
lv_obj_t *peakRearValue;

struct SegmentedGauge {
    lv_obj_t *segments[kSegmentCount]{};
};

SegmentedGauge batteryGauge;
SegmentedGauge regenGauge;

struct ControllerWidgets {
    lv_obj_t *state;
    lv_obj_t *motorCurrent;
    lv_obj_t *batteryCurrent;
    lv_obj_t *voltage;
    lv_obj_t *duty;
    lv_obj_t *fetTemp;
    lv_obj_t *fault;
};

ControllerWidgets rearWidgets;
ControllerWidgets frontWidgets;
lv_point_t vectorLinePoints[kVectorLineCapacity][2]{};
int vectorLineCount = 0;

lv_obj_t *makeLabel(lv_obj_t *parent, const char *text, const lv_font_t *font,
                    uint32_t color, lv_align_t align, int x, int y)
{
    lv_obj_t *label = lv_label_create(parent);
    lv_label_set_text(label, text);
    lv_obj_set_style_text_font(label, font, 0);
    lv_obj_set_style_text_color(label, lv_color_hex(color), 0);
    lv_obj_align(label, align, x, y);
    return label;
}

lv_obj_t *placeLabel(lv_obj_t *parent, const char *text, const lv_font_t *font,
                     uint32_t color, int x, int y, int width,
                     lv_text_align_t textAlign = LV_TEXT_ALIGN_LEFT)
{
    lv_obj_t *label = lv_label_create(parent);
    lv_label_set_text(label, text);
    lv_obj_set_pos(label, x, y);
    lv_obj_set_width(label, width);
    lv_obj_set_style_text_font(label, font, 0);
    lv_obj_set_style_text_color(label, lv_color_hex(color), 0);
    lv_obj_set_style_text_align(label, textAlign, 0);
    return label;
}

lv_obj_t *makePanel(lv_obj_t *parent, int x, int y, int width, int height,
                    uint32_t color = kPanel, int radius = 2,
                    uint32_t borderColor = kBlueDim)
{
    lv_obj_t *panel = lv_obj_create(parent);
    lv_obj_set_pos(panel, x, y);
    lv_obj_set_size(panel, width, height);
    lv_obj_set_style_bg_color(panel, lv_color_hex(color), 0);
    lv_obj_set_style_bg_opa(panel, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(panel, 1, 0);
    lv_obj_set_style_border_color(panel, lv_color_hex(borderColor), 0);
    lv_obj_set_style_radius(panel, radius, 0);
    lv_obj_set_style_pad_all(panel, 0, 0);
    lv_obj_set_style_shadow_width(panel, 0, 0);
    lv_obj_clear_flag(panel, LV_OBJ_FLAG_SCROLLABLE);
    return panel;
}

lv_obj_t *makeLine(lv_obj_t *parent, int x, int y, int width, int height,
                   uint32_t color)
{
    lv_obj_t *line = lv_obj_create(parent);
    lv_obj_set_pos(line, x, y);
    lv_obj_set_size(line, width, height);
    lv_obj_set_style_bg_color(line, lv_color_hex(color), 0);
    lv_obj_set_style_bg_opa(line, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(line, 0, 0);
    lv_obj_set_style_radius(line, 0, 0);
    lv_obj_set_style_pad_all(line, 0, 0);
    lv_obj_clear_flag(line, LV_OBJ_FLAG_SCROLLABLE);
    return line;
}

lv_obj_t *makeVectorLine(lv_obj_t *parent, int x1, int y1, int x2, int y2,
                         uint32_t color, int width = 1)
{
    if (vectorLineCount >= kVectorLineCapacity) {
        return nullptr;
    }

    const int x = std::min(x1, x2);
    const int y = std::min(y1, y2);
    lv_point_t *points = vectorLinePoints[vectorLineCount++];
    points[0].x = static_cast<lv_coord_t>(x1 - x);
    points[0].y = static_cast<lv_coord_t>(y1 - y);
    points[1].x = static_cast<lv_coord_t>(x2 - x);
    points[1].y = static_cast<lv_coord_t>(y2 - y);

    lv_obj_t *line = lv_line_create(parent);
    lv_obj_set_pos(line, x, y);
    lv_line_set_points(line, points, 2);
    lv_obj_set_style_line_color(line, lv_color_hex(color), 0);
    lv_obj_set_style_line_width(line, width, 0);
    lv_obj_set_style_line_opa(line, LV_OPA_COVER, 0);
    lv_obj_clear_flag(line, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(line, LV_OBJ_FLAG_CLICKABLE);
    return line;
}

void decorateCutFrame(lv_obj_t *panel, int width, int height, uint32_t accent,
                      int cut = 9)
{
    const int right = width - 1;
    const int bottom = height - 1;
    makeVectorLine(panel, cut, 0, right - cut, 0, accent);
    makeVectorLine(panel, right - cut, 0, right, cut, accent);
    makeVectorLine(panel, right, cut, right, bottom - cut, accent);
    makeVectorLine(panel, right, bottom - cut, right - cut, bottom, accent);
    makeVectorLine(panel, right - cut, bottom, cut, bottom, accent);
    makeVectorLine(panel, cut, bottom, 0, bottom - cut, accent);
    makeVectorLine(panel, 0, bottom - cut, 0, cut, accent);
    makeVectorLine(panel, 0, cut, cut, 0, accent);
}

lv_obj_t *makeTechPanel(lv_obj_t *parent, int x, int y, int width, int height,
                        uint32_t accent, uint32_t fill = kPanel)
{
    lv_obj_t *panel = makePanel(parent, x, y, width, height, fill, 0, accent);
    lv_obj_set_style_border_width(panel, 0, 0);
    lv_obj_set_style_bg_opa(panel, LV_OPA_80, 0);
    decorateCutFrame(panel, width, height, accent);
    return panel;
}

void makeTopBatteryIcon(lv_obj_t *parent, int x, int y)
{
    lv_obj_t *shell = makePanel(parent, x, y, 55, 24, 0x050A0E, 1, kWhite);
    lv_obj_set_style_bg_opa(shell, LV_OPA_60, 0);
    makeLine(parent, x + 55, y + 7, 4, 10, kWhite);

    constexpr int cellWidth = 9;
    for (int i = 0; i < 4; ++i) {
        topBatteryCells[i] = makeLine(shell, 5 + i * 11, 5, cellWidth, 14, kTrack);
    }
}

void setTopBatteryIcon(float percent, uint32_t color)
{
    int lit = 0;
    if (std::isfinite(percent)) {
        lit = constrain(static_cast<int>(ceilf(percent / 25.0f)), 0, 4);
    }
    for (int i = 0; i < 4; ++i) {
        if (topBatteryCells[i] != nullptr) {
            lv_obj_set_style_bg_color(topBatteryCells[i],
                                      lv_color_hex(i < lit ? color : kTrack), 0);
        }
    }
}

void makeLinkBars(lv_obj_t *parent, int x, int y)
{
    for (int i = 0; i < 4; ++i) {
        const int height = 7 + i * 4;
        linkBars[i] = makeLine(parent, x + i * 8, y + 18 - height, 5, height, kTrack);
    }
}

void setLinkBars(uint32_t color, bool active)
{
    for (int i = 0; i < 4; ++i) {
        if (linkBars[i] != nullptr) {
            lv_obj_set_style_bg_color(linkBars[i],
                                      lv_color_hex(active ? color : kTrack), 0);
        }
    }
}

void makeSpeedTicks(lv_obj_t *parent, int centerX, int centerY, int outerRadius,
                    uint32_t color)
{
    constexpr float pi = 3.1415926535f;
    for (int i = 0; i <= 40; ++i) {
        const bool major = (i % 5) == 0;
        const float degrees = 202.0f + (136.0f * i / 40.0f);
        const float radians = degrees * pi / 180.0f;
        const int innerRadius = outerRadius - (major ? 16 : 8);
        const int x1 = centerX + static_cast<int>(lroundf(cosf(radians) * innerRadius));
        const int y1 = centerY + static_cast<int>(lroundf(sinf(radians) * innerRadius));
        const int x2 = centerX + static_cast<int>(lroundf(cosf(radians) * outerRadius));
        const int y2 = centerY + static_cast<int>(lroundf(sinf(radians) * outerRadius));
        makeVectorLine(parent, x1, y1, x2, y2, color, major ? 2 : 1);
    }
}

lv_obj_t *makeMetric(lv_obj_t *parent, int x, int y, int width, int height,
                     const char *caption, lv_obj_t **captionOut = nullptr,
                     const lv_font_t *valueFont = &lv_font_montserrat_32,
                     uint32_t accent = kBlue)
{
    const uint32_t border = accent == kOrange ? kOrangeDim : kBlueDim;
    lv_obj_t *panel = makePanel(parent, x, y, width, height, kPanelBlue, 2, border);
    lv_obj_t *captionLabel = placeLabel(panel, caption, &lv_font_montserrat_16,
                                        accent, 12, 7, width - 24);
    lv_label_set_long_mode(captionLabel, LV_LABEL_LONG_WRAP);
    makeLine(panel, 12, 31, width - 24, 1, border);
    if (captionOut != nullptr) {
        *captionOut = captionLabel;
    }
    return placeLabel(panel, "--", valueFont, kWhite,
                      12, height - 42, width - 24);
}

void makeHeader(lv_obj_t *page, const char *title, bool withLink)
{
    lv_obj_t *header = makePanel(page, 10, 7, 780, 45, kPanel, 2, kBlueDim);
    placeLabel(header, "RS5", &lv_font_montserrat_32, kOrange, 10, 4, 76);
    placeLabel(header, title, &lv_font_montserrat_16, kBlue, 87, 14, 300);
    if (withLink) {
        linkDot = lv_obj_create(header);
        lv_obj_set_pos(linkDot, 610, 16);
        lv_obj_set_size(linkDot, 11, 11);
        lv_obj_set_style_radius(linkDot, LV_RADIUS_CIRCLE, 0);
        lv_obj_set_style_border_width(linkDot, 0, 0);
        lv_obj_set_style_bg_color(linkDot, lv_color_hex(kMuted), 0);
        linkLabel = placeLabel(header, "STARTING", &lv_font_montserrat_16,
                               kMuted, 632, 12, 135, LV_TEXT_ALIGN_RIGHT);
    }
}

void makeFooter(lv_obj_t *page, int activePage)
{
    static const char *const names[] = {"1 DRIVE", "2 RIDE", "3 PERF", "4 MOTORS"};
    makeLine(page, 10, 452, 780, 1, kBlueDim);
    makeLine(page, 10 + activePage * 195, 451, 195, 2, kOrange);
    for (int i = 0; i < 4; ++i) {
        placeLabel(page, names[i], &lv_font_montserrat_16,
                   i == activePage ? kOrange : kMuted,
                   10 + i * 195, 457, 195, LV_TEXT_ALIGN_CENTER);
    }
}

void recordButtonCallback(lv_event_t *)
{
    pendingAction = DashboardAction::ToggleRecording;
}

void resetButtonCallback(lv_event_t *)
{
    pendingAction = DashboardAction::ResetSession;
}

lv_obj_t *makeButton(lv_obj_t *parent, int x, int y, int width, int height,
                     const char *text, lv_event_cb_t callback,
                     lv_obj_t **labelOut = nullptr)
{
    lv_obj_t *button = lv_btn_create(parent);
    lv_obj_set_pos(button, x, y);
    lv_obj_set_size(button, width, height);
    lv_obj_set_style_radius(button, 2, 0);
    lv_obj_set_style_bg_color(button, lv_color_hex(kPanelBlue), 0);
    lv_obj_set_style_bg_opa(button, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(button, 1, 0);
    lv_obj_set_style_border_color(button, lv_color_hex(kOrangeDim), 0);
    lv_obj_set_style_shadow_width(button, 0, 0);
    lv_obj_add_event_cb(button, callback, LV_EVENT_CLICKED, nullptr);
    lv_obj_t *label = makeLabel(button, text, &lv_font_montserrat_16,
                                kWhite, LV_ALIGN_CENTER, 0, 0);
    if (labelOut != nullptr) {
        *labelOut = label;
    }
    return button;
}

lv_obj_t *makeAccentArc(lv_obj_t *parent, int x, int y, int size,
                        int startAngle, int endAngle, uint32_t color)
{
    lv_obj_t *arc = lv_arc_create(parent);
    lv_obj_set_pos(arc, x, y);
    lv_obj_set_size(arc, size, size);
    lv_arc_set_rotation(arc, 135);
    lv_arc_set_bg_angles(arc, startAngle, endAngle);
    lv_arc_set_range(arc, 0, 100);
    lv_arc_set_value(arc, 100);
    lv_obj_remove_style(arc, nullptr, LV_PART_KNOB);
    lv_obj_clear_flag(arc, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_arc_opa(arc, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_arc_width(arc, 4, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(arc, lv_color_hex(color), LV_PART_INDICATOR);
    return arc;
}

lv_obj_t *makeMeterArc(lv_obj_t *parent, int x, int y, int size,
                       int startAngle, int endAngle, uint32_t color)
{
    lv_obj_t *arc = makeAccentArc(parent, x, y, size, startAngle, endAngle, color);
    lv_arc_set_value(arc, 0);
    lv_obj_set_style_arc_opa(arc, LV_OPA_40, LV_PART_MAIN);
    lv_obj_set_style_arc_width(arc, 5, LV_PART_MAIN);
    lv_obj_set_style_arc_color(arc, lv_color_hex(kTrack), LV_PART_MAIN);
    lv_obj_set_style_arc_width(arc, 8, LV_PART_INDICATOR);
    lv_obj_set_style_arc_opa(arc, LV_OPA_COVER, LV_PART_INDICATOR);
    return arc;
}

void setArcPercent(lv_obj_t *arc, float percent)
{
    if (arc == nullptr) {
        return;
    }
    if (!std::isfinite(percent)) {
        percent = 0.0f;
    }
    lv_arc_set_value(arc, constrain(static_cast<int>(lroundf(percent)), 0, 100));
}

SegmentedGauge makeSegmentedGauge(lv_obj_t *parent, int x, int y, int width,
                                  const char *caption, lv_obj_t **valueOut,
                                  uint32_t accent, int height = 76)
{
    SegmentedGauge gauge{};
    const uint32_t border = accent == kOrange ? kOrangeDim : kBlueDim;
    lv_obj_t *panel = makeTechPanel(parent, x, y, width, height, accent, kPanel);
    placeLabel(panel, caption, &lv_font_montserrat_16, accent, 9, 7, width - 90);
    *valueOut = placeLabel(panel, "--", &lv_font_montserrat_16, kWhite,
                           width - 82, 7, 73, LV_TEXT_ALIGN_RIGHT);
    makeLine(panel, 9, 31, width - 18, 1, border);

    constexpr int gap = 3;
    const int innerWidth = width - 18;
    const int segmentWidth = (innerWidth - gap * (kSegmentCount - 1)) / kSegmentCount;
    const int segmentTop = std::max(39, height - 24);
    const int segmentHeight = height >= 70 ? 15 : 12;
    for (int i = 0; i < kSegmentCount; ++i) {
        gauge.segments[i] = makeLine(panel, 9 + i * (segmentWidth + gap), segmentTop,
                                     segmentWidth, segmentHeight, kTrack);
    }
    return gauge;
}

void setSegmentedGauge(SegmentedGauge &gauge, float fraction, uint32_t color)
{
    if (!std::isfinite(fraction)) {
        fraction = 0.0f;
    }
    fraction = std::fmax(0.0f, std::fmin(1.0f, fraction));
    const int lit = static_cast<int>(ceilf(fraction * kSegmentCount));
    for (int i = 0; i < kSegmentCount; ++i) {
        lv_obj_set_style_bg_color(gauge.segments[i],
                                  lv_color_hex(i < lit ? color : kTrack), 0);
    }
}

lv_obj_t *makeDriveSidePanel(lv_obj_t *page, int x, int y,
                             const char *caption, uint32_t accent)
{
    const uint32_t border = accent == kOrange ? kOrangeDim : kBlueDim;
    lv_obj_t *panel = makeTechPanel(page, x, y, 174, 102, accent, kPanel);
    placeLabel(panel, caption, &lv_font_montserrat_16, accent, 12, 10, 150);
    makeLine(panel, 12, 34, 150, 1, border);
    return panel;
}

void buildDrivePage(lv_obj_t *page)
{
    lv_obj_t *header = makeTechPanel(page, 10, 7, 780, 45, kBlue, kPanel);
    makeTopBatteryIcon(header, 12, 10);
    voltageValue = placeLabel(header, "--.- V", &lv_font_montserrat_32,
                              kWhite, 76, 4, 108);
    batteryValue = placeLabel(header, "--%", &lv_font_montserrat_20,
                              kGreen, 185, 10, 50, LV_TEXT_ALIGN_RIGHT);
    makeLine(header, 246, 8, 1, 29, kTrack);
    rearStatusLabel = placeLabel(header, "R --", &lv_font_montserrat_16,
                                 kMuted, 258, 13, 64);
    frontStatusLabel = placeLabel(header, "F --", &lv_font_montserrat_16,
                                  kMuted, 326, 13, 64);
    makeLine(header, 400, 8, 1, 29, kTrack);
    linkDot = lv_obj_create(header);
    lv_obj_set_pos(linkDot, 414, 17);
    lv_obj_set_size(linkDot, 10, 10);
    lv_obj_set_style_radius(linkDot, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_border_width(linkDot, 0, 0);
    lv_obj_set_style_bg_color(linkDot, lv_color_hex(kMuted), 0);
    linkLabel = placeLabel(header, "LINK", &lv_font_montserrat_16,
                           kMuted, 431, 13, 76);
    makeLinkBars(header, 511, 14);
    recordButton = makeButton(header, 552, 4, 54, 36, "REC",
                              recordButtonCallback, &recordButtonLabel);
    makeButton(header, 612, 4, 66, 36, "RST", resetButtonCallback);
    lv_obj_t *modePanel = makeTechPanel(header, 686, 4, 84, 36, kOrange, 0x120A06);
    placeLabel(modePanel, "SPORT", &lv_font_montserrat_20, kOrange,
               0, 7, 84, LV_TEXT_ALIGN_CENTER);

    lv_obj_t *powerPanel = makeDriveSidePanel(page, 10, 61, "POWER", kBlue);
    powerValue = placeLabel(powerPanel, "--.- kW", &lv_font_montserrat_32,
                            kWhite, 12, 51, 150);
    lv_obj_t *batteryCurrentPanel =
        makeDriveSidePanel(page, 10, 171, "BATTERY CURRENT", kBlue);
    batteryCurrentValue = placeLabel(batteryCurrentPanel, "--- A",
                                     &lv_font_montserrat_32, kWhite, 12, 51, 150);

    makeTechPanel(page, 192, 57, 416, 225, kTrack, kBg);
    makeSpeedTicks(page, 400, 207, 136, 0x12202A);
    makeVectorLine(page, 218, 263, 316, 263, kTrack);
    makeVectorLine(page, 316, 263, 340, 244, kTrack);
    makeVectorLine(page, 460, 244, 484, 263, kTrack);
    makeVectorLine(page, 484, 263, 582, 263, kTrack);
    adcArc = makeMeterArc(page, 285, 62, 230, 0, 58, kBlue);
    dutyArc = makeMeterArc(page, 285, 62, 230, 212, 270, kOrange);
    speedArc = lv_arc_create(page);
    lv_obj_set_pos(speedArc, 292, 72);
    lv_obj_set_size(speedArc, 216, 216);
    lv_arc_set_rotation(speedArc, 135);
    lv_arc_set_bg_angles(speedArc, 0, 270);
    lv_arc_set_range(speedArc, 0, 80);
    lv_arc_set_value(speedArc, 0);
    lv_obj_remove_style(speedArc, nullptr, LV_PART_KNOB);
    lv_obj_clear_flag(speedArc, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_arc_width(speedArc, 4, LV_PART_MAIN);
    lv_obj_set_style_arc_color(speedArc, lv_color_hex(kTrack), LV_PART_MAIN);
    lv_obj_set_style_arc_width(speedArc, 7, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(speedArc, lv_color_hex(kOrange), LV_PART_INDICATOR);
    placeLabel(page, "SPEED", &lv_font_montserrat_16, kBlue,
               300, 92, 200, LV_TEXT_ALIGN_CENTER);
    speedValue = placeLabel(page, "--.-", &lv_font_montserrat_48, kWhite,
                            275, 124, 250, LV_TEXT_ALIGN_CENTER);
    placeLabel(page, "MPH", &lv_font_montserrat_20, kMuted,
               300, 185, 200, LV_TEXT_ALIGN_CENTER);
    adcArcValue = placeLabel(page, "ADC1 --", &lv_font_montserrat_16, kBlue,
                             241, 230, 96, LV_TEXT_ALIGN_RIGHT);
    dutyArcValue = placeLabel(page, "DUTY --", &lv_font_montserrat_16, kOrange,
                              463, 230, 96);
    placeLabel(page, "0", &lv_font_montserrat_16, kMuted, 280, 246, 30);
    placeLabel(page, "80", &lv_font_montserrat_16, kMuted,
               490, 246, 30, LV_TEXT_ALIGN_RIGHT);
    faultPanel = makeTechPanel(page, 303, 250, 194, 29, kBlue, kPanel);
    faultValue = makeLabel(faultPanel, "FAULT --", &lv_font_montserrat_16,
                           kMuted, LV_ALIGN_CENTER, 0, 0);
    controllersValue = placeLabel(page, "VESC --", &lv_font_montserrat_16,
                                  kMuted, 505, 256, 90, LV_TEXT_ALIGN_RIGHT);

    lv_obj_t *motorPanel =
        makeDriveSidePanel(page, 616, 61, "MOTOR CURRENT", kOrange);
    placeLabel(motorPanel, "F", &lv_font_montserrat_16, kOrange, 12, 42, 20);
    frontMotorCurrentValue = placeLabel(motorPanel, "-- A", &lv_font_montserrat_20,
                                        kWhite, 35, 38, 127, LV_TEXT_ALIGN_RIGHT);
    placeLabel(motorPanel, "R", &lv_font_montserrat_16, kOrange, 12, 71, 20);
    rearMotorCurrentValue = placeLabel(motorPanel, "-- A", &lv_font_montserrat_20,
                                       kWhite, 35, 67, 127, LV_TEXT_ALIGN_RIGHT);

    lv_obj_t *tempPanel =
        makeDriveSidePanel(page, 616, 171, "FET TEMP", kOrange);
    placeLabel(tempPanel, "F", &lv_font_montserrat_16, kOrange, 12, 42, 20);
    frontFetTempValue = placeLabel(tempPanel, "--", &lv_font_montserrat_20,
                                   kWhite, 35, 38, 127, LV_TEXT_ALIGN_RIGHT);
    placeLabel(tempPanel, "R", &lv_font_montserrat_16, kOrange, 12, 71, 20);
    rearFetTempValue = placeLabel(tempPanel, "--", &lv_font_montserrat_20,
                                  kWhite, 35, 67, 127, LV_TEXT_ALIGN_RIGHT);

    batteryGauge = makeSegmentedGauge(page, 10, 292, 383, "BATTERY",
                                      &batteryGaugeValue, kGreen, 64);
    regenGauge = makeSegmentedGauge(page, 407, 292, 383, "REGEN",
                                    &regenValue, kYellow, 64);

    lv_obj_t *tripStrip = makeTechPanel(page, 10, 363, 780, 82, kBlue, kPanel);
    makeLine(tripStrip, 260, 10, 1, 61, kTrack);
    makeLine(tripStrip, 520, 10, 1, 61, kTrack);
    placeLabel(tripStrip, "TRIP", &lv_font_montserrat_16, kBlue,
               12, 12, 236, LV_TEXT_ALIGN_CENTER);
    driveTripValue = placeLabel(tripStrip, "0.00 MI", &lv_font_montserrat_32,
                                kWhite, 12, 37, 236, LV_TEXT_ALIGN_CENTER);
    placeLabel(tripStrip, "EFFICIENCY", &lv_font_montserrat_16, kBlue,
               272, 12, 236, LV_TEXT_ALIGN_CENTER);
    driveEfficiencyValue = placeLabel(tripStrip, "0 WH/MI", &lv_font_montserrat_32,
                                      kWhite, 272, 37, 236, LV_TEXT_ALIGN_CENTER);
    placeLabel(tripStrip, "EST. RANGE", &lv_font_montserrat_16, kBlue,
               532, 12, 236, LV_TEXT_ALIGN_CENTER);
    rangeValue = placeLabel(tripStrip, "-- MI", &lv_font_montserrat_32,
                            kWhite, 532, 37, 236, LV_TEXT_ALIGN_CENTER);

    makeFooter(page, 0);
}

void buildRidePage(lv_obj_t *page)
{
    makeHeader(page, "RIDE COMPUTER", false);
    rideLogStateValue = placeLabel(page, "NO SD", &lv_font_montserrat_16,
                                   kMuted, 610, 20, 172, LV_TEXT_ALIGN_RIGHT);

    lv_obj_t *tripPanel = makePanel(page, 14, 60, 300, 216, kPanelBlue, 2, kBlueDim);
    placeLabel(tripPanel, "TRIP", &lv_font_montserrat_20, kBlue,
               18, 14, 264, LV_TEXT_ALIGN_CENTER);
    makeLine(tripPanel, 18, 44, 264, 1, kBlueDim);
    tripValue = placeLabel(tripPanel, "0.00", &lv_font_montserrat_48, kWhite,
                           18, 68, 264, LV_TEXT_ALIGN_CENTER);
    placeLabel(tripPanel, "MILES", &lv_font_montserrat_20, kMuted,
               18, 130, 264, LV_TEXT_ALIGN_CENTER);
    rideRangeValue = placeLabel(tripPanel, "RANGE -- MI", &lv_font_montserrat_16,
                                kGreen, 18, 181, 264, LV_TEXT_ALIGN_CENTER);

    elapsedValue = makeMetric(page, 328, 60, 222, 100, "SESSION TIME");
    movingValue = makeMetric(page, 564, 60, 222, 100, "MOVING TIME");
    averageSpeedValue = makeMetric(page, 328, 174, 222, 102, "AVERAGE SPEED");
    liveConsumptionValue = makeMetric(page, 564, 174, 222, 102, "LIVE WH/MI");

    averageConsumptionValue = makeMetric(page, 14, 290, 182, 146, "AVERAGE WH/MI");
    energyValue = makeMetric(page, 210, 290, 182, 146, "NET ENERGY",
                             nullptr, &lv_font_montserrat_32, kOrange);
    odometerValue = makeMetric(page, 406, 290, 182, 146, "ODOMETER");
    uptimeValue = makeMetric(page, 602, 290, 184, 146, "VESC UPTIME",
                             nullptr, &lv_font_montserrat_32, kOrange);
    makeFooter(page, 1);
}

void buildPerformancePage(lv_obj_t *page)
{
    makeHeader(page, "PERFORMANCE", false);
    topSpeedValue = makeMetric(page, 14, 60, 250, 146, "TOP SPEED");
    peakPowerValue = makeMetric(page, 274, 60, 250, 146, "PEAK PACK POWER",
                                nullptr, &lv_font_montserrat_32, kOrange);
    performanceAverageSpeedValue =
        makeMetric(page, 534, 60, 252, 146, "AVERAGE SPEED");

    lv_obj_t *accel = makePanel(page, 14, 218, 772, 112, kPanelBlue, 2, kOrangeDim);
    placeLabel(accel, "BEST ACCELERATION", &lv_font_montserrat_16, kOrange,
               16, 9, 740, LV_TEXT_ALIGN_CENTER);
    makeLine(accel, 16, 34, 740, 1, kOrangeDim);
    placeLabel(accel, "0-20 MPH", &lv_font_montserrat_16, kMuted,
               14, 42, 238, LV_TEXT_ALIGN_CENTER);
    placeLabel(accel, "0-30 MPH", &lv_font_montserrat_16, kMuted,
               267, 42, 238, LV_TEXT_ALIGN_CENTER);
    placeLabel(accel, "0-40 MPH", &lv_font_montserrat_16, kMuted,
               520, 42, 238, LV_TEXT_ALIGN_CENTER);
    zeroTo20Value = placeLabel(accel, "--", &lv_font_montserrat_32, kWhite,
                               14, 70, 238, LV_TEXT_ALIGN_CENTER);
    zeroTo30Value = placeLabel(accel, "--", &lv_font_montserrat_32, kWhite,
                               267, 70, 238, LV_TEXT_ALIGN_CENTER);
    zeroTo40Value = placeLabel(accel, "--", &lv_font_montserrat_32, kWhite,
                               520, 70, 238, LV_TEXT_ALIGN_CENTER);

    minimumVoltageValue = makeMetric(page, 14, 342, 122, 94, "MIN VOLTS", nullptr,
                                     &lv_font_montserrat_20);
    peakBatteryValue = makeMetric(page, 144, 342, 122, 94, "PEAK PACK A", nullptr,
                                  &lv_font_montserrat_20, kOrange);
    peakRegenValue = makeMetric(page, 274, 342, 122, 94, "PEAK REGEN", nullptr,
                                &lv_font_montserrat_20);
    maximumFetValue = makeMetric(page, 404, 342, 122, 94, "MAX FET C", nullptr,
                                 &lv_font_montserrat_20, kOrange);
    peakFrontValue = makeMetric(page, 534, 342, 122, 94, "FRONT PEAK", nullptr,
                                &lv_font_montserrat_20);
    peakRearValue = makeMetric(page, 664, 342, 122, 94, "REAR PEAK", nullptr,
                               &lv_font_montserrat_20, kOrange);
    makeFooter(page, 2);
}

ControllerWidgets buildControllerPanel(lv_obj_t *page, int x, const char *title,
                                        uint32_t accent)
{
    ControllerWidgets widgets{};
    const uint32_t border = accent == kOrange ? kOrangeDim : kBlueDim;
    lv_obj_t *panel = makePanel(page, x, 60, 381, 376, kPanelBlue, 2, border);
    placeLabel(panel, title, &lv_font_montserrat_20, accent, 16, 13, 220);
    widgets.state = placeLabel(panel, "OFFLINE", &lv_font_montserrat_16, kMuted,
                               230, 17, 135, LV_TEXT_ALIGN_RIGHT);
    makeLine(panel, 16, 44, 349, 1, border);

    widgets.motorCurrent = makeMetric(panel, 12, 54, 357, 88, "MOTOR CURRENT",
                                      nullptr, &lv_font_montserrat_32, accent);
    widgets.batteryCurrent = makeMetric(panel, 12, 152, 171, 94, "BATTERY A",
                                        nullptr, &lv_font_montserrat_20, accent);
    widgets.voltage = makeMetric(panel, 195, 152, 174, 94, "INPUT VOLTS",
                                 nullptr, &lv_font_montserrat_20, accent);
    widgets.duty = makeMetric(panel, 12, 256, 110, 92, "DUTY",
                              nullptr, &lv_font_montserrat_20, accent);
    widgets.fetTemp = makeMetric(panel, 134, 256, 110, 92, "FET TEMP",
                                 nullptr, &lv_font_montserrat_20, accent);
    widgets.fault = makeMetric(panel, 256, 256, 113, 92, "FAULT",
                               nullptr, &lv_font_montserrat_16, accent);
    return widgets;
}

void buildMotorPage(lv_obj_t *page)
{
    makeHeader(page, "DUAL CONTROLLERS", false);
    rearWidgets = buildControllerPanel(page, 14, "REAR VESC", kOrange);
    frontWidgets = buildControllerPanel(page, 405, "FRONT VESC", kBlue);
    makeFooter(page, 3);
}

bool controllerFresh(const ControllerTelemetry &controller, uint32_t now)
{
    return controller.valid && now - controller.receivedAtMs <= 5000;
}

const char *compactLinkStateText(BleLinkState state)
{
    switch (state) {
        case BleLinkState::Starting: return "START";
        case BleLinkState::Scanning: return "SCAN";
        case BleLinkState::Connecting: return "CONN";
        case BleLinkState::Identifying: return "CHECK";
        case BleLinkState::Connected: return "LINK";
        case BleLinkState::WaitingForPrimary: return "WAIT";
        case BleLinkState::ConnectedBackup: return "BACKUP";
        case BleLinkState::NoTelemetry: return "NO DATA";
    }
    return "--";
}

void setTemperature(lv_obj_t *label, float value)
{
    if (!std::isfinite(value) || value < -40.0f || value > 250.0f) {
        lv_label_set_text(label, "N/A");
    } else {
        lv_label_set_text_fmt(label, "%.0f\xC2\xB0", value);
    }
}

void setControllerTemperature(lv_obj_t *label,
                              const ControllerTelemetry &controller, uint32_t now)
{
    if (!controllerFresh(controller, now)) {
        lv_label_set_text(label, "--");
    } else {
        setTemperature(label, controller.fetTemp);
    }
}

void setDriveControllerStatus(lv_obj_t *label, const char *prefix,
                              const ControllerTelemetry &controller, uint32_t now)
{
    if (!controllerFresh(controller, now)) {
        lv_label_set_text_fmt(label, "%s --", prefix);
        lv_obj_set_style_text_color(label, lv_color_hex(kMuted), 0);
        return;
    }
    lv_label_set_text_fmt(label, "%s OK", prefix);
    lv_obj_set_style_text_color(label, lv_color_hex(kGreen), 0);
}

void setTime(lv_obj_t *label, uint32_t milliseconds)
{
    const uint32_t totalSeconds = milliseconds / 1000;
    const unsigned hours = totalSeconds / 3600;
    const unsigned minutes = (totalSeconds / 60) % 60;
    const unsigned seconds = totalSeconds % 60;
    char text[20];
    snprintf(text, sizeof(text), "%02u:%02u:%02u", hours, minutes, seconds);
    lv_label_set_text(label, text);
}

void setAcceleration(lv_obj_t *label, float seconds)
{
    if (seconds <= 0.0f || !std::isfinite(seconds)) {
        lv_label_set_text(label, "--");
    } else {
        lv_label_set_text_fmt(label, "%.2f s", seconds);
    }
}

void setControllerWidgets(ControllerWidgets &widgets,
                          const ControllerTelemetry &controller, uint32_t now)
{
    if (!controllerFresh(controller, now)) {
        lv_label_set_text(widgets.state, "OFFLINE");
        lv_obj_set_style_text_color(widgets.state, lv_color_hex(kMuted), 0);
        lv_label_set_text(widgets.motorCurrent, "--");
        lv_label_set_text(widgets.batteryCurrent, "--");
        lv_label_set_text(widgets.voltage, "--");
        lv_label_set_text(widgets.duty, "--");
        lv_label_set_text(widgets.fetTemp, "--");
        lv_label_set_text(widgets.fault, "--");
        return;
    }

    lv_label_set_text_fmt(widgets.state, "%s  ID %u",
                          controller.localBleLink ? "BLE" : "CAN",
                          controller.controllerId);
    lv_obj_set_style_text_color(widgets.state,
                                lv_color_hex(controller.localBleLink ? kGreen : kBlue), 0);
    if (controller.motorCurrentValid) {
        lv_label_set_text_fmt(widgets.motorCurrent, "%.0f A", controller.motorCurrent);
    } else {
        lv_label_set_text(widgets.motorCurrent, "--");
    }
    lv_label_set_text_fmt(widgets.batteryCurrent, "%.0f A", controller.batteryCurrent);
    lv_label_set_text_fmt(widgets.voltage, "%.1f V", controller.voltage);
    lv_label_set_text_fmt(widgets.duty, "%.0f%%", controller.duty);
    setTemperature(widgets.fetTemp, controller.fetTemp);
    lv_label_set_text(widgets.fault, vescFaultText(controller.fault));
    lv_obj_set_style_text_color(widgets.fault,
                                lv_color_hex(controller.fault == 0 ? kGreen : kRed), 0);
}

void updateLogState(RideLogState state)
{
    const bool recording = state == RideLogState::Recording;
    const uint32_t color = recording ? kRed :
        state == RideLogState::Ready ? kGreen :
        state == RideLogState::Error ? kRed : kMuted;
    lv_label_set_text(recordButtonLabel, recording ? "STOP" : "REC");
    lv_obj_set_style_bg_color(recordButton,
                              lv_color_hex(recording ? kRed : kPanelBlue), 0);
    lv_obj_set_style_border_color(recordButton,
                                  lv_color_hex(recording ? kRed : kOrangeDim), 0);
    if (recordStateLabel != nullptr) {
        lv_label_set_text(recordStateLabel, rideLoggerStateText(state));
        lv_obj_set_style_text_color(recordStateLabel, lv_color_hex(color), 0);
    }
    lv_label_set_text(rideLogStateValue, rideLoggerStateText(state));
    lv_obj_set_style_text_color(rideLogStateValue, lv_color_hex(color), 0);
}

}  // namespace

void dashboardShowSplash()
{
    lv_obj_t *screen = lv_scr_act();
    lv_obj_clean(screen);
    lv_obj_set_style_bg_color(screen, lv_color_hex(0x000000), 0);
    lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, 0);
    lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *logo = lv_img_create(screen);
    lv_img_set_src(logo, &panorama_splash_logo);
    lv_obj_align(logo, LV_ALIGN_CENTER, 0, -4);
}

void dashboardBuild()
{
    lv_obj_t *screen = lv_scr_act();
    vectorLineCount = 0;
    lv_obj_clean(screen);
    lv_obj_set_style_bg_color(screen, lv_color_hex(kBg), 0);
    lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, 0);
    lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *tileview = lv_tileview_create(screen);
    lv_obj_set_size(tileview, 800, 480);
    lv_obj_set_style_bg_color(tileview, lv_color_hex(kBg), 0);
    lv_obj_set_style_bg_opa(tileview, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(tileview, 0, 0);
    lv_obj_set_style_pad_all(tileview, 0, 0);
    lv_obj_set_scrollbar_mode(tileview, LV_SCROLLBAR_MODE_OFF);

    lv_obj_t *drivePage = lv_tileview_add_tile(tileview, 0, 0, LV_DIR_RIGHT);
    lv_obj_t *ridePage = lv_tileview_add_tile(tileview, 1, 0, LV_DIR_LEFT | LV_DIR_RIGHT);
    lv_obj_t *performancePage = lv_tileview_add_tile(tileview, 2, 0, LV_DIR_LEFT | LV_DIR_RIGHT);
    lv_obj_t *motorPage = lv_tileview_add_tile(tileview, 3, 0, LV_DIR_LEFT);
    lv_obj_t *pages[] = {drivePage, ridePage, performancePage, motorPage};
    for (lv_obj_t *page : pages) {
        lv_obj_set_style_bg_color(page, lv_color_hex(kBg), 0);
        lv_obj_set_style_bg_opa(page, LV_OPA_COVER, 0);
        lv_obj_set_style_border_width(page, 0, 0);
        lv_obj_set_style_pad_all(page, 0, 0);
    }

    buildDrivePage(drivePage);
    buildRidePage(ridePage);
    buildPerformancePage(performancePage);
    buildMotorPage(motorPage);
}

void dashboardUpdate(const VescTelemetry &telemetry, BleLinkState state,
                     const RideStats &stats, RideLogState logState)
{
    const uint32_t now = millis();
    lv_label_set_text(linkLabel, compactLinkStateText(state));
    const uint32_t linkColor = state == BleLinkState::Connected ? kGreen :
        state == BleLinkState::ConnectedBackup || state == BleLinkState::Identifying ||
        state == BleLinkState::WaitingForPrimary || state == BleLinkState::NoTelemetry
            ? kOrange : kMuted;
    const bool linkActive = state == BleLinkState::Connected ||
        state == BleLinkState::ConnectedBackup || state == BleLinkState::Identifying ||
        state == BleLinkState::WaitingForPrimary || state == BleLinkState::NoTelemetry;
    lv_obj_set_style_bg_color(linkDot, lv_color_hex(linkColor), 0);
    lv_obj_set_style_text_color(linkLabel, lv_color_hex(linkColor), 0);
    setLinkBars(linkColor, linkActive);
    setDriveControllerStatus(rearStatusLabel, "R", telemetry.rearController, now);
    setDriveControllerStatus(frontStatusLabel, "F", telemetry.frontController, now);
    updateLogState(logState);

    setControllerTemperature(frontFetTempValue, telemetry.frontController, now);
    setControllerTemperature(rearFetTempValue, telemetry.rearController, now);

    if (!telemetry.valid) {
        lv_arc_set_value(speedArc, 0);
        lv_label_set_text(speedValue, "--.-");
        lv_label_set_text(voltageValue, "--.- V");
        lv_label_set_text(powerValue, "--.- kW");
        lv_label_set_text(batteryCurrentValue, "--- A");
        lv_label_set_text(frontMotorCurrentValue, "-- A");
        lv_label_set_text(rearMotorCurrentValue, "-- A");
        lv_label_set_text(adcArcValue, "ADC1 --");
        lv_label_set_text(dutyArcValue, "DUTY --");
        setArcPercent(adcArc, 0.0f);
        setArcPercent(dutyArc, 0.0f);
        lv_obj_set_style_text_color(adcArcValue, lv_color_hex(kMuted), 0);
        lv_obj_set_style_text_color(dutyArcValue, lv_color_hex(kMuted), 0);
        lv_obj_set_style_arc_color(dutyArc, lv_color_hex(kOrange),
                                   LV_PART_INDICATOR);
        lv_label_set_text(batteryGaugeValue, "--");
        lv_label_set_text(regenValue, "--");
        lv_label_set_text(controllersValue, "VESC --");
        lv_label_set_text(batteryValue, "--%");
        setTopBatteryIcon(NAN, kTrack);
        lv_label_set_text(rangeValue, "-- MI");
        lv_label_set_text(rideRangeValue, "RANGE -- MI");
        lv_label_set_text(odometerValue, "--");
        lv_label_set_text(uptimeValue, "--");
        setSegmentedGauge(batteryGauge, 0.0f, kGreen);
        setSegmentedGauge(regenGauge, 0.0f, kYellow);
        lv_label_set_text(faultValue, "FAULT --");
        lv_obj_set_style_bg_color(faultPanel, lv_color_hex(kPanel), 0);
        lv_obj_set_style_text_color(faultValue, lv_color_hex(kMuted), 0);
    } else {
        const float speedMph = std::fabs(telemetry.speedMph);
        lv_arc_set_value(speedArc, constrain(static_cast<int>(lroundf(speedMph)), 0, 80));
        const uint32_t speedColor = speedMph >= 72.0f ? kRed :
                                    speedMph >= 60.0f ? kOrange : kBlue;
        lv_obj_set_style_arc_color(speedArc, lv_color_hex(speedColor),
                                   LV_PART_INDICATOR);
        lv_label_set_text_fmt(speedValue, "%.1f", speedMph);
        lv_label_set_text_fmt(voltageValue, "%.1f V", telemetry.voltage);

        const float packPowerKw =
            telemetry.voltage * telemetry.batteryCurrent / 1000.0f;
        lv_label_set_text_fmt(powerValue, "%.1f kW", packPowerKw);
        lv_label_set_text_fmt(batteryCurrentValue, "%.0f A", telemetry.batteryCurrent);
        if (telemetry.frontMotorCurrentValid) {
            lv_label_set_text_fmt(frontMotorCurrentValue, "%.0f A",
                                  telemetry.frontMotorCurrent);
        } else {
            lv_label_set_text(frontMotorCurrentValue, "-- A");
        }
        if (telemetry.rearMotorCurrentValid) {
            lv_label_set_text_fmt(rearMotorCurrentValue, "%.0f A",
                                  telemetry.rearMotorCurrent);
        } else {
            lv_label_set_text(rearMotorCurrentValue, "-- A");
        }

        const float absoluteDuty = std::fabs(telemetry.duty);
        const uint32_t dutyColor = absoluteDuty >= 90.0f ? kRed :
                                   absoluteDuty >= 75.0f ? kOrange : kGreen;
        lv_label_set_text_fmt(dutyArcValue, "DUTY %.0f%%", telemetry.duty);
        setArcPercent(dutyArc, absoluteDuty);
        lv_obj_set_style_text_color(dutyArcValue, lv_color_hex(dutyColor), 0);
        lv_obj_set_style_arc_color(dutyArc, lv_color_hex(dutyColor),
                                   LV_PART_INDICATOR);

        if (telemetry.adc1Valid) {
            const float adcPercent = std::fmax(0.0f, std::fmin(100.0f, telemetry.adc1 * 100.0f));
            lv_label_set_text_fmt(adcArcValue, "ADC1 %.0f%%", adcPercent);
            setArcPercent(adcArc, adcPercent);
            lv_obj_set_style_text_color(adcArcValue, lv_color_hex(kBlue), 0);
        } else {
            lv_label_set_text(adcArcValue, "ADC1 --");
            setArcPercent(adcArc, 0.0f);
            lv_obj_set_style_text_color(adcArcValue, lv_color_hex(kMuted), 0);
        }

        const int batteryPercent = constrain(
            static_cast<int>(lroundf(telemetry.batteryLevel)), 0, 100
        );
        const uint32_t batteryColor = batteryPercent < 15 ? kRed :
                                      batteryPercent < 30 ? kOrange : kGreen;
        lv_label_set_text_fmt(batteryValue, "%d%%", batteryPercent);
        lv_obj_set_style_text_color(batteryValue, lv_color_hex(batteryColor), 0);
        setTopBatteryIcon(batteryPercent, batteryColor);
        lv_label_set_text_fmt(batteryGaugeValue, "%d%%", batteryPercent);
        setSegmentedGauge(batteryGauge, batteryPercent / 100.0f, batteryColor);

        const float regenAmps = std::fmax(0.0f, -telemetry.batteryCurrent);
        lv_label_set_text_fmt(regenValue, "%.0f A", regenAmps);
        setSegmentedGauge(regenGauge, regenAmps / 60.0f, kYellow);

        lv_label_set_text_fmt(controllersValue, "VESC %u", telemetry.controllerCount);
        if (telemetry.estimatedRangeValid) {
            lv_label_set_text_fmt(rangeValue, "%.1f MI", telemetry.estimatedRangeMiles);
            lv_label_set_text_fmt(rideRangeValue, "RANGE %.1f MI",
                                  telemetry.estimatedRangeMiles);
        } else {
            lv_label_set_text(rangeValue, "-- MI");
            lv_label_set_text(rideRangeValue, "RANGE -- MI");
        }
        lv_label_set_text_fmt(odometerValue, "%.1f mi",
                              telemetry.odometerMeters * 0.000621371192f);
        setTime(uptimeValue, telemetry.controllerUptimeMs);

        const bool hasFault = telemetry.fault != 0;
        lv_label_set_text_fmt(faultValue, "FAULT %s", vescFaultText(telemetry.fault));
        lv_obj_set_style_bg_color(faultPanel,
                                  lv_color_hex(hasFault ? kRed : kPanel), 0);
        lv_obj_set_style_border_color(faultPanel,
                                      lv_color_hex(hasFault ? kRed : kBlueDim), 0);
        lv_obj_set_style_text_color(faultValue,
                                    lv_color_hex(hasFault ? kWhite : kGreen), 0);
    }

    lv_label_set_text_fmt(driveTripValue, "%.2f MI", stats.tripMiles);
    lv_label_set_text_fmt(driveEfficiencyValue, "%.0f WH/MI",
                          stats.averageWhPerMile);
    lv_label_set_text_fmt(tripValue, "%.2f", stats.tripMiles);
    setTime(elapsedValue, stats.elapsedMs);
    setTime(movingValue, stats.movingMs);
    lv_label_set_text_fmt(averageSpeedValue, "%.1f mph", stats.averageSpeedMph);
    lv_label_set_text_fmt(averageConsumptionValue, "%.1f", stats.averageWhPerMile);
    lv_label_set_text_fmt(liveConsumptionValue, "%.1f", stats.liveWhPerMile);
    lv_label_set_text_fmt(energyValue, "%.1f Wh", stats.netWattHours);

    lv_label_set_text_fmt(topSpeedValue, "%.1f mph", stats.topSpeedMph);
    lv_label_set_text_fmt(peakPowerValue, "%.1f kW", stats.peakPowerKw);
    lv_label_set_text_fmt(performanceAverageSpeedValue, "%.1f mph",
                          stats.averageSpeedMph);
    setAcceleration(zeroTo20Value, stats.zeroTo20Seconds);
    setAcceleration(zeroTo30Value, stats.zeroTo30Seconds);
    setAcceleration(zeroTo40Value, stats.zeroTo40Seconds);
    if (stats.initialized) {
        lv_label_set_text_fmt(minimumVoltageValue, "%.1f V", stats.minimumVoltage);
    } else {
        lv_label_set_text(minimumVoltageValue, "--");
    }
    lv_label_set_text_fmt(peakBatteryValue, "%.0f A", stats.peakBatteryCurrent);
    lv_label_set_text_fmt(peakRegenValue, "%.0f A", stats.peakRegenCurrent);
    if (stats.initialized) {
        setTemperature(maximumFetValue, stats.maximumFetTemp);
    } else {
        lv_label_set_text(maximumFetValue, "--");
    }
    lv_label_set_text_fmt(peakFrontValue, "%.0f A", stats.peakFrontMotorCurrent);
    lv_label_set_text_fmt(peakRearValue, "%.0f A", stats.peakRearMotorCurrent);

    setControllerWidgets(rearWidgets, telemetry.rearController, now);
    setControllerWidgets(frontWidgets, telemetry.frontController, now);
}

DashboardAction dashboardTakeAction()
{
    const DashboardAction action = pendingAction;
    pendingAction = DashboardAction::None;
    return action;
}
