#pragma once

#include <Arduino.h>

enum class BleLinkState : uint8_t {
    Starting,
    Scanning,
    Connecting,
    Identifying,
    Connected,
    WaitingForPrimary,
    ConnectedBackup,
    NoTelemetry,
};

struct ControllerTelemetry {
    float voltage = 0.0f;
    float batteryCurrent = 0.0f;
    float motorCurrent = 0.0f;
    float fetTemp = 0.0f;
    float duty = 0.0f;
    uint8_t fault = 0;
    uint8_t controllerId = 0xFF;
    uint32_t receivedAtMs = 0;
    bool motorCurrentValid = false;
    bool localBleLink = false;
    bool valid = false;
};

struct VescTelemetry {
    float speedMph = 0.0f;
    float voltage = 0.0f;
    float batteryLevel = 0.0f;
    float batteryCurrent = 0.0f;
    float motorCurrent = 0.0f;
    float frontMotorCurrent = 0.0f;
    float rearMotorCurrent = 0.0f;
    float fetTemp = 0.0f;
    float motorTemp = 0.0f;
    float duty = 0.0f;
    float wattHours = 0.0f;
    float wattHoursCharged = 0.0f;
    float distanceAbsMeters = 0.0f;
    float batteryWhRemaining = 0.0f;
    float estimatedRangeMiles = 0.0f;
    float odometerMeters = 0.0f;
    float adc1 = 0.0f;
    float adc1Voltage = 0.0f;
    uint32_t controllerUptimeMs = 0;
    ControllerTelemetry frontController;
    ControllerTelemetry rearController;
    uint8_t fault = 0;
    uint8_t controllerId = 0;
    uint8_t controllerCount = 0;
    uint32_t receivedAtMs = 0;
    bool frontMotorCurrentValid = false;
    bool rearMotorCurrentValid = false;
    bool estimatedRangeValid = false;
    bool adc1Valid = false;
    bool activeControllerIsFront = false;
    bool valid = false;
};

void vescBleBegin();
void vescBleLoop();
VescTelemetry vescBleSnapshot();
BleLinkState vescBleState();
const char *vescBleStateText(BleLinkState state);
const char *vescFaultText(uint8_t fault);
