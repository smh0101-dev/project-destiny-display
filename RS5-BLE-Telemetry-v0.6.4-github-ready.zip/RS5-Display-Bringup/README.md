# RS5 four-page telemetry display

Read-only VESC dashboard, ride computer, performance recorder, and dual-motor
monitor for the Waveshare ESP32-S3-Touch-LCD-4.3B (800 x 480). It automatically
finds the two `VESC BLE UART` bridges, prefers rear/controller ID 39, and falls
back to the front bridge after 20 seconds without the primary. Swipe horizontally
between pages.

On boot, the display shows a Panorama Design Studios splash screen before the
four-page dashboard starts.

The Drive page uses the denser motorsport-style layout: thin cut-corner frames,
a larger speed dial, ADC1 and duty arcs around the speedometer, stable
rear/front health indicators, and a compact top status strip.

## Pages

1. **Drive** — motorsport-style instrument cluster with a central speedometer,
   pack voltage/percentage, power and current, separate front/rear motor current
   and FET temperature, ADC1 and duty arcs around the speedometer, battery and
   regen meters, trip efficiency/range, controller-link indicators, fault
   status, and quick `REC` and `RESET` buttons.
2. **Ride Computer** — trip and moving time, trip distance, average speed, live
   and average Wh/mi, net energy, estimated range, odometer, and VESC uptime.
3. **Performance** — top speed, peak pack power/current, peak regen, minimum
   voltage, maximum FET temperature, front/rear peak motor current, and best
   0–20, 0–30, and 0–40 MPH times since reset.
4. **Dual Controllers** — independent rear and front motor/input current,
   voltage, duty, FET temperature, fault, controller ID, and whether each reading
   arrived locally over BLE or from the other VESC over CAN.

Ride and performance statistics start with the first valid telemetry after boot
and continue until `RESET` is tapped. The range display follows VESC Tool:
remaining battery Wh divided by trip-average Wh/mi. It shows `RANGE -- MI` until
at least 0.1 mile and 0.5 Wh of usable VESC trip history exist.

The Drive-page regen gauge uses a 0–60 A display scale. The ADC1 arc uses VESC's
decoded ADC1 value, and the duty arc uses the active controller's duty cycle.
These affect only the visualizations; the numeric values remain the unmodified
VESC telemetry.

## GitHub versioning

The source is intended to live in:

`https://github.com/smh0101-dev/project-destiny-display`

Each working firmware milestone should be committed, tagged, and released using
the same version number, for example `v0.6.4`. See `CHANGELOG.md` and
`docs/VERSION_MAP.md` for the running map.

After the first GitHub setup, use:

```bash
scripts/release-version-macos.command v0.6.5 "Short release title"
```

Pushing a `v*` tag also runs the GitHub Actions firmware build and publishes the
compiled artifacts to the matching GitHub Release.

## microSD ride recording

Insert a FAT-formatted microSD card before powering the display. `SD READY`
appears when it mounts. Tap `REC` on the Drive page to create a new file such as
`/RS5/ride_0001.csv`; the button turns red and changes to `STOP`. Samples are
written twice per second and flushed every five seconds. Each recording uses the
next unused number, preserving earlier rides.

The CSV contains speed, voltage, pack current/power, battery percentage/range,
individual front/rear motor current, active link role, FET temperatures, duty,
faults, trip distance, energy, and consumption. With no card, the rest of the
dashboard works normally and shows `NO SD`. Tapping `REC` retries the mount. If
`RESET` is tapped while recording, the current file closes and a fresh numbered
file starts with the reset session.

## Automatic Bluetooth failover

Both controllers have independent BLE UART modules. The display identifies their
roles from the local controller ID and prefers rear/ID 39. If rear BLE or rear
telemetry remains offline for 20 seconds, it connects to the front bridge and
shows `FRONT BACKUP` in orange.

Individual controller requests are role-aware. On the rear link, rear values are
read locally and front values over CAN; on the front backup link, that mapping is
reversed. The requests use local-only VESC fields, so front/rear currents do not
swap or become CAN-aggregated totals. An unavailable controller shows
`OFFLINE`/`--`. If the backup BLE link is itself lost, the display retries rear
first and re-enables front after the normal 20-second delay if rear is still
unavailable.

The iOS identifiers shown by VESC Tool are not the BLE addresses visible to the
ESP32. Controller ID remains the authoritative front/rear marker.

## Safety scope

The firmware is telemetry-only. It sends value requests, CAN discovery, and
CAN-forwarded value requests. It contains no throttle, braking, motor-control,
configuration, BMS, or warning commands.

## Upload on macOS

1. Connect the display with a data-capable USB-C cable.
2. Disconnect the phone from both VESC BLE modules; each bridge normally accepts
   one BLE client at a time.
3. Double-click `upload-macos.command` and follow its BOOT/RESET directions.
4. Press **RESET** after the upload when prompted.

The first build can take several minutes while PlatformIO downloads the pinned
ESP32 platform and NimBLE-Arduino. After boot, status progresses through
`PRIMARY WAIT`, `CONNECTING`, and `VESC CHECK`, then reaches `CONNECTED` or
`FRONT BACKUP`. If it remains at `NO DATA`, capture PlatformIO Serial Monitor at
115200 baud. If speed is wrong while other data is correct, verify motor poles,
gear ratio, and wheel diameter in VESC Tool.
