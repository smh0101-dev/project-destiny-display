# Claude handoff — Destiny v0.6.23

## Current experiment

v0.6.22 still failed on hardware with the same tuning symptom: the BLE session changed/dropped while a configuration transaction was active. v0.6.23 therefore replaces `NimBLE-Arduino` with Arduino-ESP32's built-in **Bluedroid** BLE client while keeping the VESC protocol/tuning state machine as unchanged as practical.

A separate Claude review of a v0.6.18 branch found legitimate MCCONF schema-compatibility gaps and implemented broader firmware layouts. That work is not merged into v0.6.23 yet because this revision is intentionally isolating the BLE-stack variable. Mainline v0.6.20 had already demonstrated that `Read Both` can succeed, so schema rejection does not explain the persistent `Connection changed. No settings written.` failure.

## What v0.6.23 preserves

- v0.6.18 stable startup staging: BLE stack initialized before Wi-Fi; SD/NTP complete before VESC scan/connect; Wi-Fi off during active VESC BLE.
- v0.6.20 physical-bridge tuning transaction pinning and the fixed 2048-byte notification-inbox/staging-buffer mismatch.
- v0.6.21 post-`SET_MCCONF` same-bridge reconnect-and-read-back verification; destructive writes are never blindly resent after an ambiguous disconnect.
- v0.6.22 30 ms pacing between 20-byte ATT/NUS chunks for large VESC frames.
- Throttle/ADC zero is not a tuning interlock. Writes still require a stopped scooter and explicit verification.

## Bluedroid-specific changes

1. `h2zero/NimBLE-Arduino` removed from `platformio.ini`.
2. `src/vesc_ble.cpp` uses `BLEDevice`, `BLEClient`, `BLEScan`, `BLEAdvertisedDevice`, and `BLERemoteCharacteristic`.
3. Scans are restarted fresh (`is_continue=false`) and the Bluedroid result cache is cleared before each scan. This prevents duplicate filtering from suppressing reconnect candidates.
4. A disconnected Bluedroid client is deleted and recreated before the next physical BLE session. Bluedroid caches discovered services internally; reusing one client across two physical VESC bridges risks stale NUS service/characteristic handles.
5. Bluedroid default connection parameters are used initially.

## Hardware test order

1. Repeated cold boots.
2. Leave telemetry connected for 1–2 minutes and watch for spontaneous BLE drops.
3. Page 5 -> `Read Both`.
4. If reads succeed, change one safe tuning value and `Confirm Both`.
5. If a failure occurs, capture the exact on-screen message and any serial `TUNING:` / BLE lines.

## If Bluedroid fixes transport

Merge the broader MCCONF schema support from the separate Claude branch as a later revision, after BLE stability is established.
