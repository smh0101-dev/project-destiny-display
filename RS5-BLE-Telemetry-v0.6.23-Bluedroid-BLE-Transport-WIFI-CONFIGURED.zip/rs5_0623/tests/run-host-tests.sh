#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
test_binary="$(mktemp "${TMPDIR:-/tmp}/destiny-selection.XXXXXX")"
trap 'rm -f "$test_binary"' EXIT
g++ -std=c++17 -Wall -Wextra -Werror -I tests/host -I include -I src tests/selection_test.cpp -o "$test_binary"
"$test_binary"
g++ -std=c++17 -Wall -Wextra -Werror -I tests/host -I include -I src tests/temperature_test.cpp -o "$test_binary"
"$test_binary"
g++ -std=c++17 -Wall -Wextra -Werror -I tests/host -I include -I src tests/tuning_test.cpp -o "$test_binary"
"$test_binary"
g++ -std=c++17 -Wall -Wextra -Werror -fsyntax-only -DLV_CONF_INCLUDE_SIMPLE \
    -I tests/host -I include -I src -I lib/lvgl src/dashboard.cpp src/controller_menu.cpp src/tuning_page.cpp
