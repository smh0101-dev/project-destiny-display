#include <lvgl.h>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <string>
#include "../src/dashboard.h"
#include "../src/controller_menu.h"
#include "../src/tuning_page.h"
#include "../src/vesc_ble.cpp"

namespace {
uint8_t pixels[800 * 480 * 3];
lv_color_t drawPixels[800 * 24];
void flush(lv_disp_drv_t *driver, const lv_area_t *area, lv_color_t *colors) {
    for (int y = area->y1; y <= area->y2; ++y) {
        for (int x = area->x1; x <= area->x2; ++x) {
            lv_color32_t color;
            color.full = lv_color_to32(*colors++);
            if (x >= 0 && x < 800 && y >= 0 && y < 480) {
                auto *pixel = pixels + (y * 800 + x) * 3;
                pixel[0] = color.ch.red; pixel[1] = color.ch.green; pixel[2] = color.ch.blue;
            }
        }
    }
    lv_disp_flush_ready(driver);
}
lv_obj_t *findLabel(lv_obj_t *parent, const char *text) {
    if (lv_obj_check_type(parent, &lv_label_class) &&
        std::strcmp(lv_label_get_text(parent), text) == 0) return parent;
    for (uint32_t i = 0; i < lv_obj_get_child_cnt(parent); ++i) {
        if (auto *found = findLabel(lv_obj_get_child(parent, i), text)) return found;
    }
    return nullptr;
}
void click(const char *text) {
    lv_obj_t *found = findLabel(lv_scr_act(), text);
    assert(found);
    lv_obj_t *target = lv_obj_get_parent(found);
    assert(lv_obj_check_type(target, &lv_btn_class));
    lv_event_send(target, LV_EVENT_CLICKED, nullptr);
}
void render(const std::string &path) {
    lv_obj_update_layout(lv_scr_act());
    lv_refr_now(nullptr);
    FILE *file = std::fopen(path.c_str(), "wb");
    assert(file);
    std::fprintf(file, "P6\n800 480\n255\n");
    assert(std::fwrite(pixels, 1, sizeof(pixels), file) == sizeof(pixels));
    std::fclose(file);
}
}

const char *rideLoggerStateText(RideLogState) { return "SD READY"; }

int main(int argc, char **argv) {
    assert(argc == 2);
    lv_init();
    static lv_disp_draw_buf_t buffer;
    lv_disp_draw_buf_init(&buffer, drawPixels, nullptr, 800 * 24);
    static lv_disp_drv_t driver;
    lv_disp_drv_init(&driver);
    driver.hor_res = 800; driver.ver_res = 480;
    driver.draw_buf = &buffer; driver.flush_cb = flush;
    lv_disp_drv_register(&driver);
    dashboardBuild();
    lv_obj_t *tileview = lv_obj_get_child(lv_scr_act(), 0);
    assert(lv_obj_get_child_cnt(tileview) == 5);

    click("5 TUNE");
    lv_tick_inc(300); lv_timer_handler();
    assert(lv_tileview_get_tile_act(tileview) == lv_obj_get_child(tileview, 4));
    click("2 RIDE");
    lv_tick_inc(300); lv_timer_handler();
    assert(lv_tileview_get_tile_act(tileview) == lv_obj_get_child(tileview, 1));
    click("4 MOTOR");
    lv_tick_inc(300); lv_timer_handler();
    assert(lv_tileview_get_tile_act(tileview) == lv_obj_get_child(tileview, 3));
    click("1 DRIVE");
    lv_tick_inc(300); lv_timer_handler();
    assert(lv_tileview_get_tile_act(tileview) == lv_obj_get_child(tileview, 0));

    vescBleBegin();
    click(LV_SYMBOL_SETTINGS);
    vescBleLoop();
    const BLEAdvertisedDevice first(BLEAddress("c1:8d:16:21:ed:8b", 1));
    const BLEAdvertisedDevice second(BLEAddress("c2:11:22:33:44:55", 1));
    static_cast<BLEAdvertisedDeviceCallbacks &>(scanCallbacks).onResult(first);
    static_cast<BLEAdvertisedDeviceCallbacks &>(scanCallbacks).onResult(second);
    testMillis += 600;
    controllerMenuUpdate();
    render(std::string(argv[1]) + "/menu-scanning.ppm");
    click("VESC BLE UART\nc1:8d:16:21:ed:8b   -52 dBm");
    click("BACKUP (20 seconds)\nNone");
    click("VESC BLE UART\nc2:11:22:33:44:55   -52 dBm");
    testMillis += 600;
    controllerMenuUpdate();
    render(std::string(argv[1]) + "/menu-selected.ppm");
    click("Save & Connect");
    vescBleLoop();
    controllerMenuUpdate();
    lv_tick_inc(30); lv_timer_handler();
    assert(!findLabel(lv_scr_act(), "VESC CONNECTIONS"));
    assert(vescSameEndpoint(vescBleSelectionSnapshot().saved.primary,
                            endpointForAddress(first.getAddress())));
    assert(lv_obj_get_child_cnt(lv_obj_get_child(lv_scr_act(), 0)) == 5);
    render(std::string(argv[1]) + "/dashboard-after-menu.ppm");
    VescTelemetry sample;
    sample.valid = true;
    sample.speedMph = 47.3f;
    sample.voltage = 54.2f;
    sample.batteryLevel = 72;
    sample.frontController.valid = sample.rearController.valid = true;
    sample.frontController.receivedAtMs = sample.rearController.receivedAtMs = millis();
    sample.frontController.fetTemp = 59;
    sample.rearController.fetTemp = 63;
    sample.rearController.motorTemp = 78;
    dashboardUpdate(sample, BleLinkState::Connected, RideStats{}, RideLogState::Ready);
    render(std::string(argv[1]) + "/drive-temperatures.ppm");
    lv_obj_set_tile_id(lv_obj_get_child(lv_scr_act(), 0), 2, 0, LV_ANIM_OFF);
    render(std::string(argv[1]) + "/performance-temperatures.ppm");
    lv_obj_set_tile_id(lv_obj_get_child(lv_scr_act(), 0), 3, 0, LV_ANIM_OFF);
    render(std::string(argv[1]) + "/controller-temperatures.ppm");
    tuneView.loaded = true; tuneView.stationary = true; tuneView.revision = 1;
    tuneView.frontId = 38; tuneView.rearId = 39;
    tuneView.front = {140,40,10,1.10f}; tuneView.rear = {150,40,10,1.10f};
    tuningPageUpdate();
    lv_obj_set_tile_id(lv_obj_get_child(lv_scr_act(), 0), 4, 0, LV_ANIM_OFF);
    render(std::string(argv[1]) + "/tuning-page.ppm");
    click("Review Changes");
    assert(tuneAction == 0);
    render(std::string(argv[1]) + "/tuning-confirmation.ppm");
    click("Cancel"); assert(tuneAction == 0);
    click("Review Changes"); click("Confirm Both");
    assert(tuneAction == 2 && tuneDraft.phase == 150);
    std::puts("PASS: actual LVGL menu selection/save interaction; five pages retained");
}
