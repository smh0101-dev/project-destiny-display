#include <cassert>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <vector>

#include "../src/ride_logger.cpp"

namespace {
TuningSnapshot fakeTuning;
}

TuningSnapshot vescTuningSnapshot() {
    return fakeTuning;
}

bool vescTuningRead() {
    return true;
}

bool rideTimeFormatFilename(char *buffer, size_t size) {
    const char *stamp = "2026-09-05_19-22-00";
    if (size <= std::strlen(stamp)) return false;
    std::strcpy(buffer, stamp);
    return true;
}

bool rideTimeFormatIso8601(char *buffer, size_t size) {
    const char *stamp = "2026-09-05T19:22:00-0400";
    if (size <= std::strlen(stamp)) return false;
    std::strcpy(buffer, stamp);
    return true;
}

std::vector<std::string> fields(const std::string &row) {
    std::vector<std::string> result;
    std::string field;
    for (char ch : row) {
        if (ch == ',') {
            result.push_back(field);
            field.clear();
        } else {
            field += ch;
        }
    }
    result.push_back(field);
    return result;
}

int main() {
    VescTelemetry sample;
    sample.valid = true;
    sample.frontController.valid = sample.rearController.valid = true;
    sample.frontController.receivedAtMs = sample.rearController.receivedAtMs = testMillis;
    sample.frontController.fetTemp = 60;
    sample.rearController.fetTemp = 50;
    sample.frontController.motorTemp = 200; // No installed front sensor: exclude even plausible data.
    sample.rearController.motorTemp = 75;
    auto temperatures = currentTemperatures(sample, testMillis);
    assert(temperatures.maxMotor == 75 && temperatures.maxFet == 60);
    assert(std::isnan(temperatures.frontMotor));
    sample.rearController.motorTemp = 0;
    assert(currentTemperatures(sample, testMillis).maxMotor == 0);
    sample.rearController.motorTemp = -100;
    assert(std::isnan(currentTemperatures(sample, testMillis).maxMotor));
    sample.rearController.motorTemp = 75;
    assert(std::isnan(currentTemperatures(sample, testMillis + 4001).maxMotor));
    assert(std::isnan(currentTemperatures(sample, testMillis + 4001).maxFet));
    sample.frontController.fetTemp = NAN;
    assert(currentTemperatures(sample, testMillis).maxFet == 50);
    sample.frontController.fetTemp = 60;

    fakeTuning.loaded = true;
    fakeTuning.frontId = 39;
    fakeTuning.rearId = 94;
    fakeTuning.front = {140, 40, 10, 1.10f};
    fakeTuning.rear = {140, 40, 10, 1.10f};

    esp_expander::Base expander;
    rideLoggerBegin(&expander);
    assert(rideLoggerStart(sample, RideStats{}));
    assert(std::string(rideLoggerCurrentPath()) == "/RS5/RS5_2026-09-05_19-22-00.csv");

    sample.rearController.motorTemp = 40;
    // Simulate the fresh read requested automatically by REC. Same values,
    // newer tuning revision -> START_VERIFIED.
    fakeTuning.revision++;
    testMillis += 500;
    rideLoggerTick(sample, RideStats{}, testMillis);

    // Simulate a verified tuning change while recording.
    fakeTuning.front.phase = 150;
    fakeTuning.rear.phase = 150;
    fakeTuning.revision++;
    testMillis += 500;
    rideLoggerTick(sample, RideStats{}, testMillis);
    rideLoggerStop();

    std::istringstream log(File::output);
    std::string line;
    std::getline(log, line);
    const auto header = fields(line);
    assert(header.size() == 45);
    assert(header[0] == "record_type");
    assert(header[30] == "max_motor_temp_c" && header[31] == "max_fet_temp_c");
    assert(header[36] == "front_phase_a" && header[37] == "rear_phase_a");

    std::getline(log, line);
    auto row = fields(line);
    assert(row.size() == header.size());
    assert(row[0] == "config_snapshot" && row[3] == "START_CACHED");
    assert(row[4] == "1" && row[36] == "140.0" && row[37] == "140.0");

    std::getline(log, line);
    row = fields(line);
    assert(row.size() == header.size());
    assert(row[0] == "telemetry");
    assert(std::stof(row[30]) == 75 && std::stof(row[31]) == 60);
    assert(std::isnan(std::stof(row[32])) && std::stof(row[33]) == 75);

    std::getline(log, line);
    row = fields(line);
    assert(row[0] == "config_snapshot" && row[3] == "START_VERIFIED");
    assert(row[4] == "1");

    std::getline(log, line);
    row = fields(line);
    assert(row[0] == "telemetry");
    assert(std::stof(row[30]) == 40); // Current maximum, not the earlier peak.

    std::getline(log, line);
    row = fields(line);
    assert(row[0] == "config_change" && row[5] == "FRONT");
    assert(row[6] == "max_phase_current_a" && row[7] == "140.0" && row[8] == "150.0");
    assert(row[4] == "2");

    std::getline(log, line);
    row = fields(line);
    assert(row[0] == "config_change" && row[5] == "REAR");
    assert(row[6] == "max_phase_current_a" && row[4] == "2");

    std::getline(log, line);
    row = fields(line);
    assert(row[0] == "config_snapshot" && row[3] == "AFTER_CHANGE");
    assert(row[36] == "150.0" && row[37] == "150.0");

    std::getline(log, line);
    row = fields(line);
    assert(row[0] == "telemetry" && row[4] == "2");

    std::getline(log, line);
    row = fields(line);
    assert(row[0] == "config_snapshot" && row[3] == "END");
    assert(row[4] == "2" && row[36] == "150.0" && row[37] == "150.0");

    std::puts("PASS: temperature validity, timestamped filename, 45-column typed CSV, start/end config snapshots, and config-change events");
}
