#pragma once
#define CONFIG_BLUEDROID_ENABLED 1
