#pragma once
struct SpiStub {
    void setHwCs(bool) {}
    void begin(int, int, int, int) {}
};
inline SpiStub SPI;
