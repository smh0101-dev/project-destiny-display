#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>
#include "Arduino.h"

extern uint32_t testMillis;

enum esp_power_level_t { ESP_PWR_LVL_P3 = 3 };

class BLEUUID {
  public:
    explicit BLEUUID(const char *) {}
};

class BLEAddress {
  public:
    BLEAddress() = default;
    explicit BLEAddress(const String &value, uint8_t type = 0) : value_(value.c_str()), type_(type) {}
    explicit BLEAddress(const char *value, uint8_t type = 0) : value_(value ? value : ""), type_(type) {}
    uint8_t getType() const { return type_; }
    void setType(uint8_t type) { type_ = type; }
    String toString() const { return String(value_.c_str()); }
    bool operator==(const BLEAddress &other) const { return value_ == other.value_ && type_ == other.type_; }
    bool operator!=(const BLEAddress &other) const { return !(*this == other); }
  private:
    std::string value_;
    uint8_t type_ = 0;
};

class BLERemoteCharacteristic {
  public:
    using notify_callback_t = void (*)(BLERemoteCharacteristic *, uint8_t *, std::size_t, bool);
    inline static std::vector<uint8_t> written;
    inline static bool failWrite = false;
    inline static bool lastWriteResponse = true;
    bool canWrite() const { return true; }
    bool canWriteNoResponse() const { return true; }
    bool canNotify() const { return true; }
    void registerForNotify(notify_callback_t, bool = true, bool = true) {}
    bool writeValue(uint8_t *p, std::size_t n, bool response = false) {
        lastWriteResponse = response;
        if (n > 20 || failWrite) return false;
        written.insert(written.end(), p, p+n); return true;
    }
};

class BLERemoteService {
  public:
    BLERemoteCharacteristic *getCharacteristic(const char *) {
        static BLERemoteCharacteristic characteristic;
        return &characteristic;
    }
};

class BLEScan;
class BLEAdvertisedDevice {
  public:
    explicit BLEAdvertisedDevice(BLEAddress value = {}) : address_(value) {}
    int getRSSI() const { return -52; }
    bool haveName() const { return true; }
    String getName() const { return String("VESC BLE UART"); }
    bool haveServiceUUID() const { return true; }
    bool isAdvertisingService(const BLEUUID &) const { return true; }
    String toString() const { return String(""); }
    BLEAddress getAddress() const { return address_; }
    uint8_t getAddressType() const { return address_.getType(); }
  private:
    BLEAddress address_;
};

class BLEScanResults {};
class BLEClient;

class BLEClientCallbacks {
  public:
    virtual ~BLEClientCallbacks() = default;
    virtual void onConnect(BLEClient *) {}
    virtual void onDisconnect(BLEClient *) {}
};

class BLEAdvertisedDeviceCallbacks {
  public:
    virtual ~BLEAdvertisedDeviceCallbacks() = default;
    virtual void onResult(BLEAdvertisedDevice) = 0;
};

class BLEScan {
  public:
    bool isScanning() const { return scanning; }
    bool start(uint32_t, void (*cb)(BLEScanResults), bool = false) {
        scanning = true;
        if (cb) completion = cb;
        return true;
    }
    bool stop() { scanning = false; return true; }
    void clearResults() {}
    void setAdvertisedDeviceCallbacks(BLEAdvertisedDeviceCallbacks *cb, bool = false, bool = true) { callbacks = cb; }
    void setInterval(uint16_t) {}
    void setWindow(uint16_t) {}
    void setActiveScan(bool) {}
    bool scanning = false;
    BLEAdvertisedDeviceCallbacks *callbacks = nullptr;
    void (*completion)(BLEScanResults) = nullptr;
};

class BLEClient {
  public:
    bool isConnected() const { return connected_; }
    bool connect(BLEAddress address, uint8_t type = 0xFF, uint32_t = 0xffffffffu) {
        testMillis += 500;
        if (type != 0xFF) address.setType(type);
        address_ = address;
        connected_ = true;
        if (callbacks_) callbacks_->onConnect(this);
        return true;
    }
    int disconnect(uint8_t = 0) {
        const bool wasConnected = connected_;
        connected_ = false;
        if (wasConnected && callbacks_) callbacks_->onDisconnect(this);
        return 0;
    }
    BLERemoteService *getService(const char *) {
        static BLERemoteService service;
        return &service;
    }
    BLEAddress getPeerAddress() const { return address_; }
    void setClientCallbacks(BLEClientCallbacks *callbacks) { callbacks_ = callbacks; }
  private:
    bool connected_ = false;
    BLEAddress address_;
    BLEClientCallbacks *callbacks_ = nullptr;
};

class BLEDevice {
  public:
    static bool init(String = String()) { return true; }
    static void setPower(esp_power_level_t) {}
    static BLEScan *getScan() { static BLEScan scan; return &scan; }
    static BLEClient *createClient() { return new BLEClient(); }
};
