#pragma once
#include "FS.h"
#include "SPI.h"
#define CARD_NONE 0
struct SdStub {
    bool begin(int, SpiStub &, int) { return true; }
    int cardType() { return 1; }
    bool exists(const char *) { return false; }
    bool mkdir(const char *) { return true; }
    unsigned long long cardSize() { return 1024 * 1024; }
    File open(const char *, const char *) { return File{}; }
};
inline SdStub SD;
