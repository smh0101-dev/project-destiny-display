#pragma once

#include <cstddef>
#include <cstdint>

#include <string>

class String {
  public:
    String() = default;
    String(const char *value) : value_(value ? value : "") {}
    String(const std::string &value) : value_(value) {}
    const char *c_str() const { return value_.c_str(); }
    bool startsWith(const char *prefix) const { return value_.rfind(prefix ? prefix : "", 0) == 0; }
  private:
    std::string value_;
};

using std::size_t;

struct SerialStub {
    template <typename... Args> void printf(const char *, Args...) {}
    void println(const char *) {}
    void begin(unsigned long) {}
};

inline SerialStub Serial;
inline uint32_t testMillis = 1000;
inline uint32_t millis() { return testMillis; }
inline void delay(uint32_t ms) { testMillis += ms; }
template <typename T> inline T constrain(T value, T low, T high) {
    return value < low ? low : value > high ? high : value;
}

using portMUX_TYPE = int;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(x) ((void)(x))
#define portEXIT_CRITICAL(x) ((void)(x))
