#pragma once
#define LOW 0
namespace esp_expander {
class Base {
public:
    void digitalWrite(int, int) {}
};
}
