#pragma once
#include <cstdint>

#define WIFI_STA 1
#define WIFI_OFF 0
#define WL_CONNECTED 3

struct WiFiStub {
    void mode(int) {}
    void setSleep(bool) {}
    void setAutoReconnect(bool) {}
    void begin(const char *, const char *) {}
    int status() const { return WL_CONNECTED; }
    void disconnect(bool, bool) {}
};

inline WiFiStub WiFi;
inline void configTzTime(const char *, const char *, const char *, const char *) {}
