#pragma once
#include <cstddef>
#include <cstring>
#include <vector>

class Preferences {
public:
    inline static std::vector<unsigned char> stored;
    inline static bool failWrites = false;
    bool begin(const char *, bool = false) { return true; }
    void end() {}
    size_t putBytes(const char *, const void *data, size_t size) {
        if (failWrites) return 0;
        const auto *bytes = static_cast<const unsigned char *>(data);
        stored.assign(bytes, bytes + size);
        return size;
    }
    size_t getBytesLength(const char *) { return stored.size(); }
    size_t getBytes(const char *, void *data, size_t size) {
        if (stored.size() != size) return 0;
        std::memcpy(data, stored.data(), size);
        return size;
    }
};
