#pragma once
#include <string>
class File {
public:
    inline static std::string output;
    explicit operator bool() const { return true; }
    size_t print(const char *text) { output += text; return std::string(text).size(); }
    void println(const char *text) { output += text; output += '\n'; }
    void flush() {}
    void close() {}
};
#define FILE_WRITE "w"
