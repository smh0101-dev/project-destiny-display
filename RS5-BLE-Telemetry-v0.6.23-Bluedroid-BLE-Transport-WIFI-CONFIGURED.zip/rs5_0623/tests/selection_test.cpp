#include <cassert>
#include <cstdio>
#include <vector>
#include "../src/vesc_ble.cpp"

namespace {
void u16(std::vector<uint8_t> &data, uint16_t v) {
    data.push_back(v >> 8); data.push_back(v);
}
void u32(std::vector<uint8_t> &data, uint32_t v) {
    u16(data, v >> 16); u16(data, v);
}
std::vector<uint8_t> aggregate(uint8_t id) {
    std::vector<uint8_t> data{kCommGetValuesSetupSelective};
    u32(data, kTelemetryMask);
    u16(data, 300); u16(data, 0); u32(data, 1000); u32(data, 500);
    u16(data, 100); u32(data, 1000); u16(data, 555); u16(data, 740);
    u32(data, 3000000); u32(data, 0); u32(data, 16093440);
    data.push_back(0); data.push_back(id); data.push_back(2);
    u32(data, 900000); u32(data, 20000); u32(data, 30000);
    assert(data.size() == 54);
    return data;
}
std::vector<uint8_t> current(uint8_t id, int amps) {
    std::vector<uint8_t> data{kCommGetValuesSelective};
    u32(data, kControllerMask); u16(data, 300); u16(data, 650); u32(data, amps * 100);
    u32(data, 500); u16(data, 100); u16(data, 555);
    data.push_back(0); data.push_back(id);
    return data;
}
VescEndpoint endpoint(const char *address, uint8_t type = 1) {
    VescEndpoint result;
    std::snprintf(result.address, sizeof(result.address), "%s", address);
    std::snprintf(result.name, sizeof(result.name), "VESC BLE UART");
    result.addressType = type;
    return result;
}
const VescEndpoint rear = endpoint("c1:11:22:33:44:55");
const VescEndpoint front = endpoint("c2:11:22:33:44:55");
BLEAddress addressOf(const VescEndpoint &value) {
    return BLEAddress(value.address, value.addressType);
}
void advertise(const VescEndpoint &value) {
    const BLEAdvertisedDevice device(addressOf(value));
    static_cast<BLEAdvertisedDeviceCallbacks &>(scanCallbacks).onResult(device);
}
void identify(const VescEndpoint &value, uint8_t id) {
    activeBleAddress = addressOf(value);
    activeBleAddressValid = true;
    const auto packet = aggregate(id);
    pendingRequest = PendingRequest::Aggregate;
    parseTelemetryPayload(packet.data(), packet.size());
}
void apply(const VescSelection &value) {
    assert(vescBleSaveSelection(value));
    vescBleLoop();
    assert(vescBleSelectionSnapshot().result == VescSelectionResult::Saved);
    assert(vescBleTakeSelectionChanged());
    assert(!vescBleTakeSelectionChanged());
}
void controller(uint8_t id, int amps, bool local) {
    const auto packet = current(id, amps);
    pendingRequest = local ? PendingRequest::LocalController : PendingRequest::RemoteController;
    parseControllerPayload(packet.data(), packet.size());
}
void ping(uint8_t id) {
    const uint8_t packet[] = {kCommPingCan, id};
    pendingRequest = PendingRequest::PingCan;
    parsePingCanPayload(packet, sizeof(packet));
}
}

int main() {
    VescSelection profile;
    profile.mode = VescSelectionMode::Selected;
    profile.primary = rear;
    profile.backup = front;
    assert(vescSelectionValid(profile));
    auto invalid = profile;
    invalid.backup = invalid.primary;
    assert(!vescSelectionValid(invalid));
    invalid = profile; invalid.primary.address[17] = 'x';
    assert(!vescSelectionValid(invalid));
    invalid = profile; invalid.primary.addressType = 99;
    assert(!vescSelectionValid(invalid));
    assert(!vescBleSaveSelection(invalid));

    apply(profile);
    const uint32_t start = millis();
    assert(addressMatchesDesiredRole(addressOf(rear), start));
    assert(!addressMatchesDesiredRole(addressOf(front), start));
    assert(!addressMatchesDesiredRole(BLEAddress(rear.address, 0), start));
    assert(!addressMatchesDesiredRole(BLEAddress("c3:11:22:33:44:55", 1), start));
    assert(!primaryFailoverDue(start + 19999));
    assert(primaryFailoverDue(start + 20000));
    desiredRole = backupRole();
    assert(addressMatchesDesiredRole(addressOf(front), start + 20000));
    assert(addressMatchesDesiredRole(addressOf(rear), start + 20000));

    // Arbitrary IDs, including a front controller whose ID is the old rear ID.
    desiredRole = primaryRole();
    identify(rear, 7);
    assert(vescBleState() == BleLinkState::Connected);
    assert(!vescBleSnapshot().activeControllerIsFront);
    ping(39);
    controller(7, 12, true); controller(39, 34, false);
    assert(vescBleSnapshot().rearMotorCurrent == 12);
    assert(vescBleSnapshot().rearController.motorTemp == 65);
    assert(vescBleSnapshot().rearController.fetTemp == 30);
    assert(vescBleSnapshot().frontMotorCurrent == 34);
    controller(6, 99, true);
    assert(vescBleSnapshot().rearMotorCurrent == 12);
    desiredRole = backupRole();
    identify(front, 39); ping(7);
    controller(39, 56, true); controller(7, 78, false);
    assert(vescBleState() == BleLinkState::ConnectedBackup);
    assert(vescBleSnapshot().frontMotorCurrent == 56);
    assert(vescBleSnapshot().rearMotorCurrent == 78);
    recoverAfterDisconnect(activeRole, millis());
    assert(desiredRole == primaryRole());
    assert(!primaryFailoverDue(millis() + 19999));
    assert(primaryFailoverDue(millis() + 20000));

    profile.primary = front; profile.backup = rear; profile.primaryIsFront = 1;
    apply(profile);
    identify(front, 39); ping(7);
    controller(39, 23, true); controller(7, 45, false);
    assert(vescBleState() == BleLinkState::Connected);
    assert(vescBleSnapshot().frontMotorCurrent == 23);
    assert(!vescBleSnapshot().usingBackup);
    assert(vescBleSnapshot().rearMotorCurrent == 45);
    desiredRole = backupRole(); identify(rear, 7); ping(39);
    controller(7, 67, true); controller(39, 89, false);
    assert(vescBleState() == BleLinkState::ConnectedBackup);
    assert(vescBleSnapshot().rearMotorCurrent == 67);
    assert(vescBleSnapshot().usingBackup);
    assert(vescBleSnapshot().frontMotorCurrent == 89);

    // Unknown multi-peer networks must not arbitrarily fill the other motor.
    knownRearId = 0xFF; knownFrontId = 39; activeRole = ControllerRole::Front;
    localControllerId = 39;
    const uint8_t multiple[] = {kCommPingCan, 7, 8};
    parsePingCanPayload(multiple, sizeof(multiple));
    assert(!remoteControllerFound);

    // NVS round trip preserves address type and physical role; failed saves
    // leave the previous profile and current telemetry untouched.
    selection = VescSelection{};
    vescBleBegin();
    assert(selection.primaryIsFront == 1);
    assert(vescSameEndpoint(selection.primary, front));
    Preferences::failWrites = true;
    auto alternate = profile; alternate.primaryIsFront = 0;
    assert(vescBleSaveSelection(alternate));
    vescBleLoop();
    assert(vescBleSelectionSnapshot().result == VescSelectionResult::Error);
    assert(selection.primaryIsFront == 1);
    assert(!vescBleTakeSelectionChanged());
    Preferences::failWrites = false;

    // Browsing collects devices but cannot auto-connect to a list entry.
    apply(profile);
    vescBleBrowse(true); vescBleLoop();
    advertise(front); advertise(front); advertise(rear);
    assert(vescBleSelectionSnapshot().count == 2);
    vescBleLoop();
    assert(client == nullptr || !client->isConnected());
    vescBleBrowse(false);
    const auto beforeConnect = millis();
    vescBleLoop();
    assert(client && client->isConnected());
    assert(connectedAtMs >= beforeConnect);
    assert(vescBleState() == BleLinkState::Identifying);

    // Feed a fragmented, CRC-checked notification through the real parser.
    const auto payload = aggregate(39);
    std::vector<uint8_t> frame{2, static_cast<uint8_t>(payload.size())};
    frame.insert(frame.end(), payload.begin(), payload.end());
    u16(frame, crc16(payload.data(), payload.size())); frame.push_back(3);
    notificationCallback(nullptr, frame.data(), 13, true);
    vescBleLoop();
    assert(!vescBleSnapshot().valid);
    notificationCallback(nullptr, frame.data() + 13, frame.size() - 13, true);
    vescBleLoop();
    assert(vescBleSnapshot().valid);
    assert(vescBleSnapshot().activeControllerIsFront);
    assert(vescBleState() == BleLinkState::Connected);

    // Pending bytes from the old vehicle cannot populate the new selection.
    notificationCallback(nullptr, frame.data(), frame.size(), true);
    profile.primary = rear; profile.backup = {}; profile.primaryIsFront = 0;
    apply(profile);
    assert(!vescBleSnapshot().valid);
    assert(!primaryFailoverDue(millis() + 60000));
    assert(!addressMatchesDesiredRole(addressOf(front), millis() + 60000));

    // Exercise the main loop across the exact 20-second startup boundary,
    // then lose the backup and recover the primary in the same power session.
    profile.backup = front;
    apply(profile);
    const uint32_t offlineAt = millis();
    vescBleLoop();
    testMillis = offlineAt + 19999;
    advertise(front); vescBleLoop();
    assert(!client->isConnected());
    testMillis = offlineAt + 20000;
    vescBleLoop();
    assert(client->isConnected());
    assert(client->getPeerAddress() == addressOf(front));
    identify(front, 88);
    assert(vescBleState() == BleLinkState::ConnectedBackup);
    client->disconnect(); vescBleLoop();
    assert(desiredRole == primaryRole());
    advertise(rear); vescBleLoop();
    assert(client->isConnected());
    assert(client->getPeerAddress() == addressOf(rear));

    VescSelection unpaired;
    unpaired.mode = VescSelectionMode::Unpaired;
    apply(unpaired);
    advertise(rear); testMillis += 60000; vescBleLoop();
    assert(!client->isConnected());
    assert(vescBleState() == BleLinkState::Unpaired);
    assert(!addressMatchesDesiredRole(addressOf(rear), millis()));
    selection = VescSelection{}; vescBleBegin();
    assert(selection.mode == VescSelectionMode::Unpaired);
    Preferences::stored.assign(3, 0xFF);
    selection = VescSelection{}; vescBleBegin();
    assert(selection.mode == VescSelectionMode::Unpaired);

    // Firmware upgrade retains the pre-selection RS5 discovery path.
    Preferences::stored.clear(); selection = VescSelection{}; vescBleBegin();
    identify(rear, 39);
    assert(vescBleState() == BleLinkState::Connected);
    std::puts("PASS: saved selection, role mapping, failover, browsing, notification isolation, and legacy mode");
}
