#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
render_dir="${1:?Pass an absolute output directory}"
mkdir -p "$render_dir/objects"
while IFS= read -r source; do
    object="$render_dir/objects/${source//\//_}.o"
    if [[ ! -f "$object" || "$source" -nt "$object" || include/lv_conf.h -nt "$object" ]]; then
        gcc -std=c99 -O0 -DLV_CONF_INCLUDE_SIMPLE -I include -I lib/lvgl -c "$source" -o "$object"
    fi
done < <(find lib/lvgl/src -name '*.c')
g++ -std=c++17 -DLV_CONF_INCLUDE_SIMPLE -I tests/host -I include -I src -I lib/lvgl \
    tests/render_menu.cpp src/dashboard.cpp src/controller_menu.cpp src/tuning_page.cpp src/panorama_splash.cpp \
    "$render_dir"/objects/*.o -lm -o "$render_dir/render-menu"
"$render_dir/render-menu" "$render_dir"
