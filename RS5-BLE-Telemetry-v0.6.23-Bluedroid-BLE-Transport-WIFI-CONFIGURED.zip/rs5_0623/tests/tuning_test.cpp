#include <cassert>
#include <vector>
#include <string>
#include "../src/vesc_ble.cpp"
using Bytes=std::vector<uint8_t>;
Bytes fixture(int variant=0) {
    const auto l=tuning_config::layouts[variant]; Bytes b(l.size);
    for(size_t i=0;i<b.size();++i)b[i]=uint8_t(i*13);
    for(int i=0;i<4;++i)b[i]=uint8_t(l.signature>>(24-i*8));
    assert(tuning_config::patch(b.data(),b.size(),{140,40,10,1.1f}));return b;
}
void fresh() {
    testMillis+=50;
    telemetry.valid=telemetry.adc1Valid=true;telemetry.adc1=telemetry.speedMph=0;
    telemetry.receivedAtMs=telemetry.adcReceivedAtMs=millis();
    auto &f=telemetry.frontController;auto &r=telemetry.rearController;
    f.valid=r.valid=true; f.receivedAtMs=r.receivedAtMs=millis();
    f.controllerId=38;r.controllerId=39;f.duty=r.duty=f.motorCurrent=r.motorCurrent=0;
}
void init(bool backup=false) {
    tunePhase=TunePhase::Idle;tuneView=TuningSnapshot{};tuneAction=0;tuneNeedsRefresh=false;
    tuneTransportPinActive=false;tunePinnedRole=ControllerRole::Unknown;
    tuneWriteSettleUntil=0;tuningClearPostWriteRecovery();
    tuneTouched[0]=tuneTouched[1]=tuneVerified[0]=tuneVerified[1]=false;
    static BLEClient c; c.connect(BLEAddress("c1:22:33:44:55:66",1));client=&c;
    activeBleAddress=BLEAddress("c1:22:33:44:55:66",1);activeBleAddressValid=true;
    static BLERemoteCharacteristic rx;rxCharacteristic=&rx;
    BLERemoteCharacteristic::failWrite=false;
    BLERemoteCharacteristic::lastWriteResponse=true;
    activeRole=backup ? ControllerRole::Front : ControllerRole::Rear;
    localControllerId=backup?38:39;remoteControllerId=backup?39:38;remoteControllerFound=true;
    pendingRequest=PendingRequest::None;acceptNotifications=true;
    packetBufferLength=inboxLength=0;inboxOverflow=false;fresh();
}
Bytes outgoing() {
    const auto b=BLERemoteCharacteristic::written;assert(b.size()>=5);
    size_t h=b[0]==2?2:3;size_t n=h==2?b[1]:(size_t(b[1])<<8|b[2]);
    assert(b.size()==h+n+3);assert(b.back()==3);
    assert(crc16(b.data()+h,n)==(uint16_t(b[h+n])<<8|b[h+n+1]));
    return Bytes(b.begin()+h,b.begin()+h+n);
}
Bytes send() {
    fresh();BLERemoteCharacteristic::written.clear();
    assert(tuningService(millis()));return outgoing();
}
void settleWrite() {
    testMillis += kTuningWriteSettleMs + 50;
}
void response(uint8_t command,Bytes body={}) {
    Bytes p={command};p.insert(p.end(),body.begin(),body.end());
    Bytes frame=p.size()>255?Bytes{3,uint8_t(p.size()>>8),uint8_t(p.size())}:Bytes{2,uint8_t(p.size())};
    frame.insert(frame.end(),p.begin(),p.end());const auto crc=crc16(p.data(),p.size());
    frame.push_back(uint8_t(crc>>8));frame.push_back(uint8_t(crc));frame.push_back(3);
    // Production notification inbox, packet assembly and CRC parser, fragmented.
    for(size_t i=0;i<frame.size();i+=17){
        const size_t n=std::min(size_t(17),frame.size()-i);
        notificationCallback(nullptr,frame.data()+i,n,true);drainNotifications();
    }
}
void load(const Bytes &a,const Bytes &b) {
    assert(vescTuningRead());assert(send()==Bytes{14});
    assert(tuningTransportLocked());
    assert(tuningPinnedAddressMatches(BLEAddress("c1:22:33:44:55:66",1)));
    assert(!tuningPinnedAddressMatches(BLEAddress("c1:22:33:44:55:67",1)));
    assert(!BLERemoteCharacteristic::lastWriteResponse); // Read-only MCCONF uses NUS write command.
    response(14,a);
    assert((send()==Bytes{34,remoteControllerId,14}));response(14,b);
    assert(vescTuningSnapshot().loaded);assert(!tuningTransportLocked());
}
void start(const TuningValues &v,const Bytes &a,const Bytes &b) {
    assert(vescTuningApply(v,vescTuningSnapshot().revision));
    assert(send()==Bytes{14});response(14,a);
    assert((send()==Bytes{34,remoteControllerId,14}));response(14,b);
}
int main() {
    TuningValues target{150,45,12,1.12f};
    for(int version=0;version<3;++version){
        auto a=fixture(version);TuningValues decoded;
        assert(tuning_config::read(a.data(),a.size(),decoded));assert(decoded.phase==140);
        assert(tuning_config::patch(a.data(),a.size(),target));
        assert(tuning_config::read(a.data(),a.size(),decoded));assert(tuning_config::equal(target,decoded));
        a[0]^=1;assert(!tuning_config::patch(a.data(),a.size(),target));
    }
    assert(!tuning_config::valid({NAN,40,10,1.1f}));assert(!tuning_config::valid({140,101,10,1.1f}));
    assert(!tuning_config::valid({10,40,11,1.1f}));assert(!tuning_config::valid({140,40,10,1.16f}));
    assert(tuning_config::valid({140,40,0,1.0f}));
    // Read Both is non-destructive and never depends on throttle/ADC state.
    init(); telemetry.adc1=.5f; assert(vescTuningRead());
    assert(send()==Bytes{14}); response(14,fixture(0));
    assert((send()==Bytes{34,remoteControllerId,14})); response(14,fixture(2));
    assert(vescTuningSnapshot().loaded);assert(!tuningTransportLocked());
    for(bool backup:{false,true}) {
        init(backup);auto a=fixture(0),b=fixture(2);auto different=b;
        assert(tuning_config::patch(b.data(),b.size(),{130,35,5,1}));
        load(a,b);
        auto view=vescTuningSnapshot();assert(view.front.phase==(backup?140:130));assert(view.rear.phase==(backup?130:140));
        assert(!vescTuningApply(target,view.revision+1));
        start(target,a,b);
        const uint32_t writeStartedAt=testMillis;
        auto write=send();assert(write[0]==13);assert(write.size()==a.size()+1);
        const size_t framedWriteBytes=write.size()+(write.size()>255?3:2)+3;
        const size_t framedWriteChunks=(framedWriteBytes+kBleTxChunkBytes-1)/kBleTxChunkBytes;
        assert(testMillis-writeStartedAt>=50+(framedWriteChunks-1)*kBleTxChunkPaceMs);
        assert(BLERemoteCharacteristic::lastWriteResponse); // Destructive write stays acknowledged.
        const auto before=a;assert(tuning_config::patch(a.data(),a.size(),target));
        assert(Bytes(write.begin()+1,write.end())==a);
        const auto *l=tuning_config::layout(a.data(),a.size());
        for(size_t i=0;i<a.size();++i)if(!(i>=8&&i<12)&&!(i>=16&&i<20)&&!(i>=l->fw&&i<l->fw+4)&&!(i>=l->overmod&&i<l->overmod+2))assert(a[i]==before[i]);
        settleWrite();assert(send()==Bytes{14});response(14,a);
        assert((send()==Bytes{34,remoteControllerId,14}));response(14,b);
        write=send();assert(write[0]==34&&write[1]==remoteControllerId&&write[2]==13);
        assert(tuning_config::patch(b.data(),b.size(),target));assert(Bytes(write.begin()+3,write.end())==b);
        settleWrite();assert((send()==Bytes{34,remoteControllerId,14}));response(14,b);
        view=vescTuningSnapshot();assert(!view.busy&&view.loaded&&view.frontVerified&&view.rearVerified);
        assert(std::string(view.status).find("BOTH")!=std::string::npos);
    }
    init();auto a=fixture(),b=fixture();load(a,b);
    // v0.6.16: a non-zero, stale, or unavailable throttle/ADC reading must not
    // block an otherwise stationary tuning update.
    telemetry.adc1Valid=false; telemetry.adc1=.5f; telemetry.adcReceivedAtMs=0;
    tuningService(millis()); assert(vescTuningSnapshot().stationary);
    assert(vescTuningApply(target,tuneView.revision));
    assert(send()==Bytes{14});a[100]^=1;response(14,a);assert(tunePhase==TunePhase::Failed&&!tuneTouched[0]);
    init();a=fixture();load(a,b);start(target,a,b);send();settleWrite();send();response(14,a);
    assert(tunePhase==TunePhase::Failed&&!tuneTouched[1]); // Hardware clamped/rejected new values.
    init();load(a,b);start(target,a,b);send();settleWrite();send();tuningTimeout();
    // A verification timeout inside the known post-write blackout is recoverable:
    // do not resend SET_MCCONF and do not drop the pinned BLE session yet.
    assert(client->isConnected());assert(tunePostWriteRecovery&&tunePhase==TunePhase::VerifyLocal);
    testMillis+=kTuningRecoveryTimeoutMs+1;tuningService(millis());
    assert(!client->isConnected());assert(std::string(tuneView.status).find("partial")!=std::string::npos);
    response(13);assert(tunePhase==TunePhase::Failed); // Late/optional ACK ignored.
    init();auto unknown=a;unknown[0]^=1;assert(vescTuningRead());send();response(14,unknown);
    assert(!tuneView.loaded&&!tuneTouched[0]);
    init();load(a,b);start(target,a,b);remoteControllerId=42;
    tuningService(millis());assert(!tuneTouched[0]&&tunePhase==TunePhase::Failed);
    init();load(a,b);start(target,a,b);BLERemoteCharacteristic::failWrite=true;
    fresh();tuningService(millis());assert(tunePhase==TunePhase::Failed&&!client->isConnected());
    init();load(a,b);start(target,a,b);send();settleWrite();send();
    assert(tuning_config::patch(a.data(),a.size(),target));response(14,a);
    fresh();telemetry.speedMph=10;tuningService(millis());assert(!tuneTouched[1]&&tunePhase==TunePhase::Failed);
    init();load(a,b);assert(vescTuningApply(target,tuneView.revision));resetConnectionState();
    assert(!tuneView.loaded&&tuneAction==0);

    // v0.6.22 retains v0.6.21 recovery: once a complete SET_MCCONF write has been handed to the BLE
    // bridge, an expected post-write disconnect must preserve the transaction,
    // reconnect only to the pinned bridge, and verify rather than resend.
    init();a=fixture();b=fixture(2);load(a,b);start(target,a,b);
    auto firstWrite=send();assert(firstWrite[0]==13);
    assert(tunePhase==TunePhase::VerifyLocal&&tunePostWriteRecovery&&tuningTransportLocked());
    const auto pinned=tunePinnedBleAddress;const auto pinnedRole=tunePinnedRole;
    client->disconnect();assert(tuningHandleTransportDisconnect(millis()));
    resetConnectionState(true);
    assert(tunePhase==TunePhase::VerifyLocal&&tunePostWriteRecovery&&tuningTransportLocked());
    assert(tuningPinnedAddressMatches(pinned));
    // Rebuild exactly the same route as the normal pinned reconnect/identify path.
    client->connect(pinned);activeBleAddress=pinned;activeBleAddressValid=true;activeRole=pinnedRole;
    static BLERemoteCharacteristic recoveryRx;rxCharacteristic=&recoveryRx;acceptNotifications=true;
    localControllerId=39;remoteControllerId=38;remoteControllerFound=true;fresh();
    testMillis+=kTuningWriteSettleMs+50;
    auto verifyAfterReconnect=send();assert(verifyAfterReconnect==Bytes{14});
    assert(tuning_config::patch(a.data(),a.size(),target));response(14,a);
    // Local verification proceeds to the remote pre-write recheck without
    // re-sending the already accepted local SET_MCCONF.
    assert(tunePhase==TunePhase::CheckRemoteFinal);
    std::puts("PASS: config schemas, byte preservation, fragmented long frames, 30 ms paced multi-chunk BLE TX, pinned BLE tuning transport, post-write reconnect-and-verify, both BLE roles, confirmation gating, throttle-independent stationary writes, dual write/read-back, movement, changed config, unsupported firmware, route loss, timeouts and partial writes");
}
