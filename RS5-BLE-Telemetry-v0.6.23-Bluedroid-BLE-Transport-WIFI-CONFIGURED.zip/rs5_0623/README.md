# Destiny v0.6.23 - Bluedroid BLE transport


> **v0.6.23 build note:** Arduino-ESP32 3.3+ normally uses NimBLE on ESP32-S3. This project deliberately forces Bluedroid through pioarduino HybridCompile (`custom_sdkconfig`). The first compile after unzipping v0.6.23 may take noticeably longer because PlatformIO rebuilds the Arduino/ESP-IDF framework libraries; later builds are cached. The normal `upload-macos.command` workflow is unchanged and does not erase NVS.

### v0.6.23 BLE-stack replacement

This diagnostic/production candidate replaces `NimBLE-Arduino` with the built-in Arduino-ESP32 **Bluedroid** BLE/GATT client. The VESC protocol is otherwise deliberately unchanged: Nordic UART Service framing, exact physical-bridge tuning pinning, CAN forwarding to the second VESC, 30 ms pacing for large writes, and post-write reconnect/read-back verification all remain in place. Each reconnect creates a fresh GATT client so service/characteristic handles cannot leak across the two physical BLE bridges.


### v0.6.18 startup sequencing

The current startup path remains deliberately staged: display/UI -> Bluedroid BLE stack initialization -> microSD/logger and one-shot NTP startup work -> Wi-Fi fully off -> VESC scan/connect. No blocking SD or Wi-Fi work is allowed to begin while a VESC BLE session is active.


VESC dashboard, ride computer, performance recorder, and dual-motor
monitor for the Waveshare ESP32-S3-Touch-LCD-4.3B (800 x 480). Choose a primary
VESC BLE UART bridge and an optional backup from the touchscreen. Selections
survive power cycles. Swipe horizontally between five pages, including controller tuning,
or tap the persistent DRIVE / RIDE / PERF / MOTOR / TUNE footer tabs to jump directly.

On boot, the display shows a Panorama Design Studios splash screen before the
five-page dashboard starts.

The Drive page uses the denser motorsport-style layout: thin cut-corner frames,
a larger speed dial, ADC1 and duty arcs around the speedometer, stable
rear/front health indicators, and a compact top status strip.

## Choose controllers

1. Tap the gear at the top-right of the Drive page, or **Connections** on the
   Dual Controllers page.
2. Tap **PRIMARY**, then select a nearby device by its name and full Bluetooth
   address. The current connection is preselected when available.
3. Select **Rear** or **Front** for that primary controller's motor position.
4. Optionally tap **BACKUP**, then select the other motor's BLE module. Its motor
   position is the opposite of the primary. **No backup** disables failover.
5. Tap **Save & Connect**. The display stores the selection, closes any active
   recording, starts a fresh ride session, and connects to the chosen primary.

**Cancel** leaves the saved selection and ride session unchanged. **Forget all**
followed by **Save & Connect** clears both choices and stops automatic connections.
The menu remains available while disconnected. The refresh button rescans;
browsing does not intentionally disconnect an existing telemetry connection.
Nearby entries are UART candidates; **VESC CHECK** verifies a telemetry response
before the dashboard reports a working connection.

Before any selection has been saved, the existing RS5 automatic discovery
(rear ID 39, front fallback after 20 seconds) is retained for upgrade continuity.
Saved selections use the motor position you chose, with no fixed controller ID.
For a single-controller vehicle, select its motor position and leave backup empty.

This version supports the same Nordic UART Service VESC modules as the current
display. It stores one vehicle's primary/backup pair, not a multi-vehicle profile
library. Assign both modules from the same vehicle. Each bridge normally allows
one client, so disconnect VESC Tool on your phone to make a busy module available.
If a module's Bluetooth address changes, select it again from the menu.

## Pages

1. **Drive** — motorsport-style instrument cluster with a central speedometer,
   pack voltage/percentage, power and current, separate front/rear motor current
   and current maximum motor/FET temperatures, ADC1 and duty arcs around the speedometer, battery and
   regen meters, trip efficiency/range, controller-link indicators, fault
   status, and quick `REC` and `RESET` buttons.
2. **Ride Computer** — trip and moving time, trip distance, average speed, live
   and average Wh/mi, net energy, estimated range, odometer, and VESC uptime.
3. **Performance** — top speed, peak pack power/current, peak regen, minimum
   voltage, maximum FET temperature, front/rear peak motor current, and best
   0–20, 0–30, and 0–40 MPH times since reset. Also shows live front/rear motor and FET temperatures.
4. **Dual Controllers** — independent rear and front motor/input current,
   voltage, duty, FET/motor temperature, fault, controller ID, and whether each reading
   arrived locally over BLE or from the other VESC over CAN.

5. **Tuning** — read existing front/rear settings, adjust a shared proposal,
   review the warning, then explicitly confirm writing both controllers.

The tuning writer verifies each controller by reading its full motor configuration
back after the write. It does **not** require the one-byte `COMM_SET_MCCONF`
acknowledgement to arrive before verification, because some BLE/CAN bridge paths
can delay or drop that ACK even after the controller has already stored the
configuration. Writes are still serialized: the locally connected controller is
written and verified first, then the CAN-connected controller is written and
verified. A controller is never reported as verified unless its explicit
`GET_MCCONF` read-back matches the requested values.


Ride and performance statistics start with the first valid telemetry after boot
and continue until `RESET` is tapped. The range display follows VESC Tool:
remaining battery Wh divided by trip-average Wh/mi. It shows `RANGE -- MI` until
at least 0.1 mile and 0.5 Wh of usable VESC trip history exist.

The Drive-page regen gauge uses a 0–60 A display scale. The ADC1 arc uses VESC's
decoded ADC1 value, and the duty arc uses the active controller's duty cycle.
These affect only the visualizations; the numeric values remain the unmodified
VESC telemetry.

## GitHub versioning

The source is intended to live in:

`https://github.com/smh0101-dev/project-destiny-display`

Each working firmware milestone should be committed, tagged, and released using
the same version number, for example `v0.6.9`. See `CHANGELOG.md` and
`docs/VERSION_MAP.md` for the running map.

After the first GitHub setup, use:

```bash
scripts/release-version-macos.command v0.6.9 "Reliable dual-controller tuning"
```

Pushing a `v*` tag also runs the GitHub Actions firmware build and publishes the
compiled artifacts to the matching GitHub Release.

## microSD ride recording

Insert a FAT-formatted microSD card before powering the display. `SD READY`
appears when it mounts. Tap `REC` on the Drive page to create a new ride log.
When the display has a valid network-synchronized clock, filenames use the local
date and time, for example:

`/RS5/RS5_2026-09-05_19-22-00.csv`

If the clock has not been synchronized yet, logging still works and safely falls
back to `/RS5/RS5_UNDATED_0001.csv` rather than inventing a date. A collision in
the same second receives `_02`, `_03`, and so on.

Samples are written twice per second and flushed every five seconds. The CSV is a
fixed 45-column typed log. `record_type=telemetry` rows contain the normal ride
data. `record_type=config_snapshot` rows capture the four controller-tuning
values for both Front and Rear controllers at the beginning and end of the
recording. `record_type=config_change` rows record the controller, parameter, old
value, new value, and resulting full configuration if any of those settings
change while recording. Telemetry rows carry `config_revision`, so a later
analysis can associate each section of the ride with the exact logged settings.

The configuration fields are max phase current, max battery current, field
weakening, and overmodulation, with Front/Rear controller IDs. Starting a
recording also requests a fresh, read-only configuration read from both
controllers. If the scooter is already moving or the read cannot complete, the
log records that the opening configuration is pending/unavailable instead of
claiming stale values are verified. Any previously loaded values can still be
captured, and later verified values or changes are recorded when available.

Every row also has a `wall_time` field when the clock is valid. The original
telemetry remains present: speed, voltage, pack current/power, battery
percentage/range, individual front/rear motor current, active link role, FET and
motor temperatures, duty, faults, trip distance, energy, and consumption.

### Wi-Fi/NTP clock setup

The firmware keeps credentials out of the release source. On macOS, double-click
`configure-network-macos.command` once; it prompts for the Wi-Fi SSID/password
(the password entry is hidden) and creates `include/network_config.local.h`.
Alternatively, copy `include/network_config.example.h` to that filename and edit
it manually. The local file is git-ignored. The default timezone is US Eastern
Time with DST transitions and can be changed in that file. The startup sequence
keeps the Bluetooth stack initialization ahead of Wi-Fi, then performs the one-shot
NTP sync **before** VESC scanning/connection begins. Wi-Fi is turned fully off
before the display starts connecting to either VESC bridge, so no runtime Wi-Fi
activity competes with the active BLE link. If that one-shot sync is unavailable,
logging continues with the `RS5_UNDATED_####.csv` fallback for that boot.

## Automatic Bluetooth failover

Both controllers may have independent BLE UART modules. The selected primary is
preferred. If it cannot connect or stops supplying telemetry for 20 seconds, the
saved backup becomes eligible and the display shows `BACKUP` in orange. A returning
primary remains eligible during backup scanning; a missing backup cannot lock it
out. A healthy backup connection is retained until it drops or you save a selection.

Individual controller requests are role-aware. On the rear link, rear values are
read locally and front values over CAN; on the front backup link, that mapping is
reversed. The requests use local-only VESC fields, so front/rear currents do not
swap or become CAN-aggregated totals. An unavailable controller shows
`OFFLINE`/`--`. If the backup BLE link is itself lost, the display retries the
selected primary first and re-enables backup after the normal 20-second delay.
Front can be primary and Rear can be backup; the current/temperature labels and
CSV backup flag follow those choices.

The iOS identifiers shown by VESC Tool may differ from the BLE addresses visible
to the ESP32. Select the address listed on the display. Controller IDs are learned
from valid replies and used to route individual readings. An unassigned CAN
network with multiple possible peers is left unmapped instead of guessing which
one is the opposite motor. Individual readings still require the vehicle's CAN
link; two separate BLE modules alone do not supply both currents simultaneously.

## Safety scope

Normal dashboard and logging traffic is telemetry-only. The Tuning page is the
one intentional configuration-write path: it can persistently change only max
phase current, max battery current, field weakening, and overmodulation after the
explicit both-controller confirmation and read-back checks described below. It
does not send throttle or braking commands and does not change unrelated motor
configuration fields. Starting a ride log may issue a read-only configuration
request so the file can capture the current settings.

## Upload on macOS

1. Connect the display with a data-capable USB-C cable.
2. Disconnect the phone from both VESC BLE modules; each bridge normally accepts
   one BLE client at a time.
3. Double-click `upload-macos.command` and follow its BOOT/RESET directions.
4. Press **RESET** after the upload when prompted.

The first build can take several minutes while PlatformIO downloads the pinned
ESP32 platform. The Bluedroid BLE library is built into Arduino-ESP32; v0.6.23 no longer downloads the external NimBLE-Arduino dependency. After boot, status progresses through
`PRIMARY WAIT`, `CONNECTING`, and `VESC CHECK`, then reaches `CONNECTED` or
`BACKUP`. If it remains at `NO DATA`, capture PlatformIO Serial Monitor at
115200 baud. If speed is wrong while other data is correct, verify motor poles,
gear ratio, and wheel diameter in VESC Tool.

## Validation

Host regression tests: `bash tests/run-host-tests.sh` (requires g++).
Actual LVGL menu rendering and interaction checks:
`bash tests/render-menu.sh /absolute/output/directory` (requires gcc and g++).
See `docs/v0.6.8-validation.md` for completed checks and the hardware checklist.

## Current temperature readings (v0.6.6)

Drive shows MAX MOTOR TEMP above MAX FET TEMP. These are the highest valid
readings right now, not historical ride peaks. Readings older than four seconds,
nonfinite readings, and values outside -40 to 250 C are unavailable (N/A).
The rear motor thermistor is enabled; the front is disabled in
`include/sensor_config.h`. Enable the front flag after installing and configuring
its sensor. A valid zero-degree reading remains valid. This hardware setting
also applies when changing controller selections.

CSV retains the original 22 columns and appends `max_motor_temp_c`,
`max_fet_temp_c`, `front_motor_temp_c`, and `rear_motor_temp_c`.
Unavailable temperatures are written as `nan`, not zero. Each row's maxima use
the same validity rules as the dashboard.

## Page 5: Controller tuning

Stop the scooter, tap **5 TUNE** (or swipe there), and tap **Read Both**. The page shows
existing Front and Rear settings alongside the proposed **NEW / EACH** values.
The proposal initially copies the rear settings, without writing anything.
Adjust with +/- and tap **Review Changes**. The pop-up says:

> You're about to modify the settings on BOTH controllers.

It lists both controller IDs, existing values, proposed values and the combined
battery limit. **Cancel** writes nothing; **Confirm Both** starts the operation.

| Field | VESC setting | Input step | Display input bounds |
| --- | --- | --- | --- |
| Max phase current | l_current_max | 5 A | 1–200 A per controller |
| Max battery current | l_in_current_max | 1 A | 1–100 A per controller |
| Field weakening | foc_fw_current_max | 1 A | 0–50 A, no higher than phase current |
| Overmodulation | foc_overmod_factor | 0.01 | 1.00–1.15 |

These bounds are editor limits, not motor, battery or controller ratings. A
40 A battery setting means 40 A on each controller, potentially 80 A combined.
Phase-current scaling, regen, thermistors and all other configuration fields
are preserved individually. Each controller's existing full config is read;
only the four specified fields are patched. **This saves persistent settings
in both controllers**, rather than a temporary display profile.

Both motors must supply fresh, stopped telemetry. Throttle/ADC1 zero is not part
of the tuning-write interlock in v0.6.16; a biased, stale, or unavailable ADC1
reading will not block an otherwise stationary update. The operation uses the active BLE bridge and forwards requests to
the other controller over CAN; it works from either primary or backup BLE.
It cannot write to an absent CAN peer or a single-controller setup.

Layouts are recognized by exact signature and payload size for stock VESC
6.06, 7.00 and 7.01 motor configurations. Unknown/custom layouts show the
signature and are blocked before any writes. This is not a VESC firmware update.

The display rechecks existing configurations before writing and reads each
controller back. The one-byte set-config ACK is optional; matching explicit
read-back is authoritative. Only two verified responses produce success.
Configuration timeouts end the BLE session to discard late replies. A failure
can leave one controller updated: the status reports Front/Rear verification
and asks you to read both again. It does not silently roll back or retry writes.
Avoid simultaneous setting edits through VESC Tool during this operation.
