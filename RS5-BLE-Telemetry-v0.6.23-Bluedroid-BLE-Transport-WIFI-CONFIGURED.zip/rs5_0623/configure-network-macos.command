#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

python3 - <<'PY'
from pathlib import Path
from getpass import getpass

print("RS5 display Wi-Fi / NTP setup")
print("This is only used to obtain trustworthy date/time for ride logs in v0.6.9.")
ssid = input("Wi-Fi SSID: ").strip()
password = getpass("Wi-Fi password (hidden): ")
default_tz = "EST5EDT,M3.2.0/2,M11.1.0/2"
tz = input(f"POSIX timezone [{default_tz}]: ").strip() or default_tz

if not ssid:
    raise SystemExit("SSID cannot be blank.")

def c_string(value: str) -> str:
    return value.replace('\\', '\\\\').replace('"', '\\"')

content = f'''#pragma once

#define RS5_WIFI_SSID "{c_string(ssid)}"
#define RS5_WIFI_PASSWORD "{c_string(password)}"
#define RS5_TIMEZONE "{c_string(tz)}"
#define RS5_NTP_SERVER_1 "time.cloudflare.com"
#define RS5_NTP_SERVER_2 "pool.ntp.org"
#define RS5_NTP_SERVER_3 "time.google.com"
'''
path = Path("include/network_config.local.h")
path.write_text(content)
print(f"\nSaved {path}. It is git-ignored and will be used on the next build/upload.")
PY

printf '\n'
read -r -p "Press Return to close."
