#pragma once

// Copy this file to include/network_config.local.h and fill in your network.
// network_config.local.h is git-ignored so credentials do not enter releases.
#define RS5_WIFI_SSID "YOUR_WIFI_NAME"
#define RS5_WIFI_PASSWORD "YOUR_WIFI_PASSWORD"

// Eastern Time with automatic US daylight-saving transitions.
// Change this if you want filenames and wall-clock timestamps in another zone.
#define RS5_TIMEZONE "EST5EDT,M3.2.0/2,M11.1.0/2"

#define RS5_NTP_SERVER_1 "time.cloudflare.com"
#define RS5_NTP_SERVER_2 "pool.ntp.org"
#define RS5_NTP_SERVER_3 "time.google.com"
