#pragma once

// Local Wi-Fi/NTP configuration.
// This file is intentionally git-ignored.
#define RS5_WIFI_SSID "Get Out of My Swamp"
#define RS5_WIFI_PASSWORD "paradisebythedashboardlight"

// Eastern Time with automatic US daylight-saving transitions.
#define RS5_TIMEZONE "EST5EDT,M3.2.0/2,M11.1.0/2"

#define RS5_NTP_SERVER_1 "time.cloudflare.com"
#define RS5_NTP_SERVER_2 "pool.ntp.org"
#define RS5_NTP_SERVER_3 "time.google.com"
