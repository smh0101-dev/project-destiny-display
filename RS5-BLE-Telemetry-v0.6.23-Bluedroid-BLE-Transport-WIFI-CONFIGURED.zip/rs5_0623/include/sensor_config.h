#pragma once

// Physical thermistors installed on this vehicle. Enable Front after fitting
// and configuring its thermistor in VESC Tool; zero degrees can be a real value.
constexpr bool kFrontMotorTemperatureEnabled = false;
constexpr bool kRearMotorTemperatureEnabled = true;
