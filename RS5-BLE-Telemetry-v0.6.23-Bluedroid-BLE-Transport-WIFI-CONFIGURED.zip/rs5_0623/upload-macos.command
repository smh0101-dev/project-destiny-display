#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"

PIO="$HOME/.platformio/penv/bin/pio"
if [[ ! -x "$PIO" ]]; then
    echo "PlatformIO Core was not found at $PIO"
    echo "Install the PlatformIO extension in Visual Studio Code, open it once, then retry."
    read -r -p "Press Return to close."
    exit 1
fi

ports=(/dev/cu.usbmodem*)
if [[ ! -e "${ports[0]}" ]]; then
    echo "No /dev/cu.usbmodem device was found."
    echo "Reconnect the display with a data-capable USB-C cable, then retry."
    read -r -p "Press Return to close."
    exit 1
fi

PORT="${ports[0]}"
echo "Target port: $PORT"
if [[ ! -f include/network_config.local.h ]]; then
    echo
    echo "NOTE: No include/network_config.local.h found."
    echo "Ride logging will still work, but filenames will use RS5_UNDATED_####.csv"
    echo "until the display has a trustworthy clock. Run configure-network-macos.command"
    echo "once if you want Wi-Fi/NTP date-time filenames."
fi
echo
echo "Put the display into download mode:"
echo "  1. Hold BOOT."
echo "  2. Tap and release RESET."
echo "  3. Release BOOT."
echo
read -r -p "Do that now, wait two seconds, then press Return."

"$PIO" run -e waveshare-43b -t upload --upload-port "$PORT"

echo
echo "Upload complete. Tap RESET once to start the dashboard."
read -r -p "Press Return to close."
